<template>
  <div class="detail-page">
    <!-- 页头固定：场景 / 靶场 / 当前状态 / 停止并恢复（DR-02 真实接线，降级显式注明） -->
    <PageHeader :title="`演练详情 ${shortId}`" subtitle="页面刷新或关闭后作业继续；重新打开恢复真实状态，断网不显示假成功。">
      <template #actions>
        <el-button @click="loadDetail(false)" :loading="loading">刷新</el-button>
        <el-button
          type="danger"
          :disabled="!!stopDisabledReason || stopping"
          :loading="stopping"
          :title="stopDisabledReason || 'POST /api/drills/{id}/stop（幂等键一次生成）；一旦注入可能发生，停止必须先进入恢复路径'"
          @click="onStop"
        >停止并恢复</el-button>
        <el-button text @click="router.push('/drills')">返回列表</el-button>
      </template>
    </PageHeader>

    <div class="card head-card">
      <div class="hd-item">
        <div class="hd-label">场景</div>
        <div class="hd-value">{{ drill?.scenarioName ?? drill?.scenarioId ?? '—' }}</div>
      </div>
      <div class="hd-item">
        <div class="hd-label">靶场</div>
        <div class="hd-value">{{ drill?.targetEnv ?? '—' }}</div>
      </div>
      <div class="hd-item">
        <div class="hd-label">当前状态</div>
        <div class="hd-value">{{ drill?.state ?? '—' }}</div>
        <div class="hd-note">CLOSED 仅表示恢复核验完成（§7.4）</div>
        <div v-if="stopAcceptedNote" class="hd-note hd-stop">{{ stopAcceptedNote }}</div>
      </div>
      <div class="hd-item">
        <div class="hd-label">结果（outcome）</div>
        <div class="hd-value">{{ drill?.outcome ?? '—' }}</div>
        <div class="hd-note">PASS / FAIL / INCONCLUSIVE 另存，不由 CLOSED 代替</div>
        <div v-if="drill?.terminalReason" class="hd-note">卡因：{{ drill.terminalReason }}</div>
      </div>
    </div>

    <!-- 权限 / 不存在 / 接口不可用分状态：不把 403 与 404 混同为「未部署」（PAGE-02） -->
    <el-result
      v-if="detailState === 'notfound'"
      icon="warning"
      title="演练作业不存在"
      :sub-title="`GET /api/drills/${route.params.drillId} 返回 404：该作业不存在或当前不可见（ID 可能有误）。`"
    >
      <template #extra>
        <el-button :loading="loading" @click="loadDetail(false)">重试</el-button>
        <el-button @click="router.push('/drills')">返回列表</el-button>
      </template>
    </el-result>
    <el-result
      v-else-if="detailState === 'not-ready'"
      icon="warning"
      title="演练详情接口不可用（403/404）"
      sub-title="GET /api/drills/{id} 被拒绝：可能无操作权限（403）或后端版本滞后未部署（404）。无法确认该作业状态。"
    >
      <template #extra>
        <el-button :loading="loading" @click="loadDetail(false)">重试</el-button>
      </template>
    </el-result>
    <EmptyState v-else-if="detailState === 'error'" kind="error" @retry="loadDetail(false)" />

    <!-- DU10 断网诚实面：轮询失败保留旧数据；详情/事件分别标失败，互不顶替（PAGE-07） -->
    <div v-if="connIssue" class="card conn-note">
      连接中断：{{ connIssueText }}；显示 {{ fmtTime(lastLoadedAt) }} 最近成功加载的数据，
      作业在服务端继续，恢复连接后自动刷新。
    </div>

    <!-- 时间线：八阶段（§7.2）；详情接口 timeline 有真实相位时高亮当前阶段，enteredAt 只取真实事件 -->
    <div class="card timeline-card">
      <div class="tl-title">作业时间线</div>
      <div class="tl-note">
        阶段语义来自方案 §7.4：QUEUED→PRECHECK→INJECTING→OBSERVING→RECOVERING→VERIFYING→CLOSED；
        调查、注入与恢复分别呈现，报告成功不代表故障已解除。
        {{ detailState === 'ok'
          ? '当前为详情接口返回的真实时间线：enteredAt 只取真实事件，无事件如实「—」。'
          : '详情未就绪/加载失败时仅展示 §7.2 八阶段骨架（无真实相位）；原始事件账本见下方「事件流」分区。' }}
      </div>
      <ol class="tl-list">
        <li
          v-for="(s, i) in timelineStages" :key="s.key ?? s.name"
          class="tl-item" :class="{ 'tl-active': s.status === 'ACTIVE', 'tl-failed': s.status === 'FAILED' }"
        >
          <span class="tl-idx">{{ i + 1 }}</span>
          <div class="tl-body">
            <div class="tl-name">{{ s.name }}<span class="tl-phase mono">{{ s.phase }}</span></div>
            <div class="tl-desc">{{ s.desc }}</div>
            <div class="tl-entered">进入时间：{{ fmtTime(s.enteredAt) }}</div>
          </div>
          <span class="tl-state" :class="stateCls(s.status)">{{ stateText(s.status) }}</span>
        </li>
      </ol>
    </div>

    <!-- 事件流：drill_event 原始账本（§7.2/DR-06）。与时间线并存——时间线 = 后端推导的
         八阶段态，事件流 = insert-only 原始事件账本；seq 游标增量，浏览器重开状态一致（DU10） -->
    <div class="card events-card">
      <div class="tl-title">事件流（原始账本）</div>
      <div class="tl-note">
        与上方时间线的区别：时间线是后端从事件推导的八阶段态；本区是 drill_event 原始账本
        （insert-only，按 seq 单调序逐条落账）。作业进行中每 5 秒按游标增量拉取新事件，
        浏览器关闭重开后从头重拉，状态一致（DU10）。
      </div>
      <template v-if="eventsState === 'ok'">
        <ul v-if="events.length" class="ev-list">
          <li v-for="ev in events" :key="ev.seq" class="ev-item">
            <span class="ev-badge" :class="evBadgeCls(ev.eventType)">{{ evTypeText(ev.eventType) }}</span>
            <div class="ev-body">
              <div class="ev-meta">
                <span class="mono">#{{ ev.seq }}</span>
                <span>{{ fmtTime(ev.createdAt) }}</span>
                <span>操作者：{{ ev.actor ?? '—' }}</span>
                <span v-if="ev.fromState || ev.toState" class="mono">{{ ev.fromState ?? '—' }} → {{ ev.toState ?? '—' }}</span>
              </div>
              <!-- payload 为 jsonb 原文：文本插值渲染（禁 v-html 防注入），长文本默认折叠 -->
              <pre class="ev-payload">{{ payloadText(ev) }}</pre>
              <el-button v-if="payloadLong(ev)" size="small" text @click="togglePayload(ev.seq)">
                {{ expandedSeqs.has(ev.seq) ? '收起 payload' : '展开 payload' }}
              </el-button>
            </div>
          </li>
        </ul>
        <EmptyState v-else kind="empty" description="该演练尚无事件记录：事件由服务端动作与 worker 执行实时落账。" />
        <div class="pager">
          <span class="muted">已加载 {{ events.length }} 条</span>
          <el-button v-if="eventsHasMore" :loading="eventsFetching" @click="loadMoreEvents">加载更多</el-button>
        </div>
      </template>
      <!-- 403/404 分状态：无权限 / 接口未部署 / 真实错误 / 真实空账本区分，不伪造空态 -->
      <el-result
        v-else-if="eventsState === 'not-ready'"
        icon="warning"
        title="事件流接口不可用（403/404）"
        sub-title="GET /api/drills/{id}/events 被拒绝：可能无操作权限（403）或事件投影未部署（404）。就绪前不展示任何模拟事件。"
      >
        <template #extra>
          <el-button :loading="eventsLoading" @click="loadEvents">重试</el-button>
        </template>
      </el-result>
      <EmptyState v-else-if="eventsState === 'error'" kind="error" @retry="loadEvents" />
      <div v-else v-loading="true" class="loading-box" />
    </div>

    <!-- 关联与证据分区：找不到关联就显示「尚未关联」 -->
    <div class="card link-card">
      <div class="tl-title">关联对象与证据</div>
      <dl class="preview-list">
        <div class="pv-row">
          <dt>关联告警</dt>
          <dd v-if="detailState === 'ok'" class="mono">{{ drill?.related?.incidentId ?? '尚未关联（DR-06 事件投影未回填）' }}</dd>
          <dd v-else>尚未关联（依赖 DR-06 事件投影）</dd>
        </div>
        <div class="pv-row">
          <dt>关联调查 Run</dt>
          <dd v-if="detailState === 'ok'" class="mono">{{ drill?.related?.runId ?? '尚未关联（DR-06 事件投影未回填）' }}</dd>
          <dd v-else>尚未关联（依赖 DR-06 事件投影）</dd>
        </div>
        <div class="pv-row"><dt>关联报告</dt><dd>尚未关联（依赖 DR-06 事件投影）</dd></div>
        <div class="pv-row">
          <dt>参数与审计</dt>
          <dd v-if="detailState === 'ok'">
            模板 digest <span class="mono">{{ drill?.templateDigest ?? '—' }}</span>；
            冻结参数 <span class="mono">{{ paramsText }}</span>
          </dd>
          <dd v-else>尚未关联（启动时冻结模板与参数，依赖 DR-02/DR-06）</dd>
        </div>
      </dl>
    </div>
  </div>
</template>

<script setup>
// 演练详情（/drills/:drillId，DR-02 接线）：页头固定四要素 + 「停止并恢复」真实接线——
// POST /api/drills/{id}/stop（幂等键 crypto.randomUUID）；受理 202 只表示取消中/恢复中
// （显示「恢复中」而非「已恢复」，核验完成才 CLOSED，§7.4/DU12）；RECOVERY_FAILED 占位 409
// 如实展示服务端「需处理恢复而非停止」。时间线八阶段取详情接口 timeline：有真实相位高亮
// 当前阶段（ACTIVE），无事件 enteredAt 如实「—」。事件流分区取 GET /{id}/events：
// seq 游标增量（加载更多 + DU10 有界轮询，终态/隐藏/卸载即停），接口未就绪（403/404）/
// 加载失败/真实空账本三态区分。断网保留旧数据并如实标「连接中断」，不显示假成功（DU10）。
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import EmptyState from '../components/common/EmptyState.vue'
import PageHeader from '../components/common/PageHeader.vue'
import { ApiNotReadyError, getDrill, listDrillEvents, newIdempotencyKey, stopDrill } from '../api/drills'
import { fmtTime } from '../utils/format'

const route = useRoute()
const router = useRouter()

// PAGE-07：按 drillId 建立本页生命周期——路由切到另一演练时取消旧请求语义、
// 清空详情/事件/cursor/展开状态、递增 generation，旧响应一律不回写
const drillId = computed(() => String(route.params.drillId ?? ''))
let generation = 0

const drill = ref(null)
const detailState = ref('loading') // loading | ok | notfound | not-ready | error
const loading = ref(false)
const stopping = ref(false)
const detailIssue = ref(false)    // 详情路轮询失败（保留旧数据，DU10）
const eventsIssue = ref(false)    // 事件路失败（与详情路独立，互不顶替）
const lastLoadedAt = ref(null)

const connIssue = computed(() => detailIssue.value || eventsIssue.value)
const connIssueText = computed(() =>
  [detailIssue.value && '详情', eventsIssue.value && '事件流'].filter(Boolean).join('与') + '加载失败')

// 事件流（drill_event 原始账本）
const events = ref([])
const eventsState = ref('loading') // loading | ok | not-ready | error
const eventsLoading = ref(false)
const eventsFetching = ref(false)  // 增量面（加载更多/轮询共用），防并发重入
const eventsHasMore = ref(false)
const expandedSeqs = ref(new Set())

// DU10 有界轮询：仅作业非终态时按 seq 游标增量拉取，不把 WebSocket 作为前置（§7.2）
const POLL_MS = 5000

const shortId = computed(() => {
  const id = String(route.params.drillId ?? '')
  return id.length > 16 ? `${id.slice(0, 8)}…${id.slice(-4)}` : id
})

// §7.4 终态集：停止非法（后端 409 CONFLICT_TERMINAL）
const TERMINAL = new Set(['CLOSED', 'CANCELLED', 'FAILED'])

// 停止按钮禁用原因：接口不可用/不存在/终态/已受理——显式注明，不伪造可点；RECOVERY_FAILED
// 占位保持可点，由服务端 409 如实返回「需处理恢复而非停止」
const stopDisabledReason = computed(() => {
  if (detailState.value === 'notfound') return '作业不存在（404），无可停止对象'
  if (detailState.value === 'not-ready') {
    return '作业状态无法确认（详情接口 403/404）：不允许盲停'
  }
  if (detailState.value !== 'ok') return '作业详情加载后可操作'
  if (TERMINAL.has(drill.value?.state)) return `作业已终态（${drill.value.state}），停止非法（§7.4）`
  if (drill.value?.stopRequestedAt) {
    return `停止请求已受理（${fmtTime(drill.value.stopRequestedAt)}）：恢复中——受理≠恢复完成，核验完成才 CLOSED`
  }
  return ''
})

// 受理后头卡注明「恢复中」而非「已恢复」（DU12 语义）
const stopAcceptedNote = computed(() => {
  if (detailState.value !== 'ok' || !drill.value?.stopRequestedAt) return ''
  if (TERMINAL.has(drill.value?.state)) return ''
  return `停止已受理（${fmtTime(drill.value.stopRequestedAt)}）：当前为恢复中，非「已恢复」`
})

// §7.2 八阶段骨架（详情未就绪时展示）；key 与后端 DrillTimeline 键序一致
const STAGE_SKELETON = [
  { key: 'ACCEPTED', name: '受理', phase: 'QUEUED', desc: '作业持久化并返回 202 受理，完成以查询状态为准。' },
  { key: 'PRECHECK', name: '预检', phase: 'PRECHECK', desc: '服务端检查靶场健康、资源水位、旧故障残留、管理面/观测面与恢复能力。' },
  { key: 'INJECTION', name: '注入', phase: 'INJECTING', desc: '复用受控 ScenarioDriver 激活故障；激活回执先持久化再产生流量。' },
  { key: 'TRAFFIC', name: '产生测试流量', phase: 'INJECTING', desc: '按完整 recipe 产生 chaos- 前缀测试流量；中断后不得继续发流量。' },
  { key: 'SYMPTOM_WAIT', name: '等待症状', phase: 'OBSERVING', desc: '等待期望症状与告警 firing，显示真实阶段，不伪造精确百分比。' },
  { key: 'AGENT_INVESTIGATION', name: 'Agent 调查', phase: 'OBSERVING', desc: '调查 Agent 在不知情（无 GT）前提下诊断；报告状态独立关联。' },
  { key: 'STOP', name: '停止', phase: 'RECOVERING', desc: '停止测试流量并发起恢复；202 仅代表接受恢复，不是恢复完成。' },
  { key: 'VERIFY_RECOVERY', name: '核验恢复', phase: 'VERIFYING→CLOSED', desc: '恢复判据全部满足且无残留 firing 后 CLOSED；CLOSED 不代表演练目标达成。' },
]
const STAGE_DESCS = Object.fromEntries(STAGE_SKELETON.map(s => [s.key, s.desc]))

// 详情接口 timeline（[{key,name,phase,status,enteredAt}]）优先；无真实数据回退骨架
const timelineStages = computed(() => {
  const tl = drill.value?.timeline
  if (detailState.value === 'ok' && Array.isArray(tl) && tl.length) {
    return tl.map(s => ({ ...s, desc: STAGE_DESCS[s.key] ?? '' }))
  }
  return STAGE_SKELETON.map(s => ({ ...s, status: null, enteredAt: null }))
})

const STAGE_STATUS_TEXT = {
  DONE: '已完成', ACTIVE: '进行中', FAILED: '失败',
  CANCELLED: '已取消', PENDING: '未开始', SKIPPED: '已跳过',
}
const stateText = s => (s == null ? '未开始' : STAGE_STATUS_TEXT[s] ?? s)
const stateCls = s => ({
  'tl-st-active': s === 'ACTIVE',
  'tl-st-done': s === 'DONE',
  'tl-st-failed': s === 'FAILED' || s === 'CANCELLED',
})

const paramsText = computed(() => {
  const p = drill.value?.params
  if (!p || typeof p !== 'object') return '—'
  const text = JSON.stringify(p)
  return text.length > 160 ? `${text.slice(0, 160)}…` : text
})

// ---------------------------------------------------------------- 事件流

// 事件类型徽章词汇（V86 event_type 枚举；未知类型如实透传原文，不猜译）
const EVENT_TYPE_TEXT = {
  PHASE_TRANSITION: '相位迁移',
  PRECHECK_RESULT: '预检结果',
  STOP_REQUESTED: '停止请求',
  OUTCOME_RECORDED: '结论落档',
  WORKER_NOTE: '执行注记',
}
const evTypeText = t => EVENT_TYPE_TEXT[t] ?? t ?? '未知类型'
const evBadgeCls = t => ({
  'ev-b-transition': t === 'PHASE_TRANSITION',
  'ev-b-stop': t === 'STOP_REQUESTED',
  'ev-b-outcome': t === 'OUTCOME_RECORDED',
})

// payload = jsonb 原文；默认折叠 160 字符（与 paramsText 同式），展开态按 seq 记录
const PAYLOAD_COLLAPSE = 160
const payloadFull = ev => (typeof ev.payload === 'string' ? ev.payload : JSON.stringify(ev.payload)) ?? '—'
const payloadLong = ev => payloadFull(ev).length > PAYLOAD_COLLAPSE
function payloadText(ev) {
  const full = payloadFull(ev)
  return expandedSeqs.value.has(ev.seq) || full.length <= PAYLOAD_COLLAPSE
    ? full
    : `${full.slice(0, PAYLOAD_COLLAPSE)}…`
}
function togglePayload(seq) {
  const next = new Set(expandedSeqs.value)
  if (next.has(seq)) next.delete(seq)
  else next.add(seq)
  expandedSeqs.value = next
}

const lastSeq = () => (events.value.length ? events.value[events.value.length - 1].seq : 0)

// 增量拉取（加载更多/轮询共用）：afterSeq = 已加载末条 seq；按 seq 去重防竞态重条；
// 迟到响应（generation 已推进）一律丢弃，不拼进新演练的账本（PAGE-07）
async function fetchEventsAfter(afterSeq, limit) {
  if (eventsFetching.value) return false
  eventsFetching.value = true
  const gen = generation
  try {
    const d = await listDrillEvents(drillId.value, { afterSeq, limit })
    if (gen !== generation) return false
    const seen = new Set(events.value.map(e => e.seq))
    events.value = events.value.concat((d.items ?? []).filter(e => !seen.has(e.seq)))
    eventsHasMore.value = d.nextCursor != null
    eventsState.value = 'ok'
    eventsIssue.value = false
    return true
  } catch (e) {
    if (gen !== generation) return false
    if (e instanceof ApiNotReadyError) {
      eventsState.value = 'not-ready'
    } else if (eventsState.value === 'ok') {
      eventsIssue.value = true // 已有账本时断轮询不翻错误态（DU10：断网不显示假成功）
    } else {
      eventsState.value = 'error'
    }
    return false
  } finally {
    eventsFetching.value = false
  }
}

// 首屏/重试：从头（afterSeq=0）整页重拉——重开浏览器状态一致，不依赖客户端记忆（DU10）
async function loadEvents() {
  eventsLoading.value = true
  const gen = generation
  try {
    const d = await listDrillEvents(drillId.value, { afterSeq: 0, limit: 50 })
    if (gen !== generation) return
    events.value = d.items ?? []
    eventsHasMore.value = d.nextCursor != null
    eventsState.value = 'ok'
    eventsIssue.value = false
  } catch (e) {
    if (gen !== generation) return
    eventsState.value = e instanceof ApiNotReadyError ? 'not-ready' : 'error'
  } finally {
    eventsLoading.value = false
  }
}

async function loadMoreEvents() {
  const ok = await fetchEventsAfter(lastSeq(), 50)
  if (!ok && eventsIssue.value && gen() === generation) ElMessage.error('加载更多失败，请重试')
}
const gen = () => generation

// ---------------------------------------------------------------- 有界轮询（DU10/PAGE-07）

let pollTimer = null
let pollBusy = false // 上一轮未完成不叠加（慢请求不再堆积）
function startPoll() {
  if (pollTimer) return // 已在轮询：不重置计时器（避免手动刷新后 cadence 漂移）
  pollTimer = setInterval(pollTick, POLL_MS)
}
function stopPoll() {
  if (pollTimer) {
    clearInterval(pollTimer)
    pollTimer = null
  }
}
async function pollTick() {
  if (document.hidden) return // 隐藏页面暂停（恢复可见时立即补一次）
  if (pollBusy) return
  if (detailState.value === 'loading') return // 首屏仍在加载：本轮跳过，绝不当作终态停轮询
  if (detailState.value !== 'ok' || TERMINAL.has(drill.value?.state)) {
    stopPoll() // 终态/不可用即停：有界
    return
  }
  pollBusy = true
  try {
    await loadDetail(true)
    if (eventsState.value === 'ok') await fetchEventsAfter(lastSeq(), 200)
  } finally {
    pollBusy = false
  }
}

// 首屏/手动刷新/轮询三态共用：成功非终态确保轮询在跑（首屏慢、手动重试成功都恢复）；
// 终态即停；notfound/not-ready 无可轮询对象也停
async function loadDetail(silent = false) {
  const gen0 = generation
  if (!silent) loading.value = true
  try {
    const d = await getDrill(drillId.value)
    if (gen0 !== generation) return
    drill.value = d
    detailState.value = 'ok'
    lastLoadedAt.value = new Date().toISOString()
    detailIssue.value = false
    if (TERMINAL.has(d?.state)) stopPoll()
    else startPoll()
  } catch (e) {
    if (gen0 !== generation) return
    if (silent) {
      detailIssue.value = true // 轮询失败保留旧数据，如实标连接中断
      return
    }
    if (e instanceof ApiNotReadyError && e.status === 404) detailState.value = 'notfound'
    else if (e instanceof ApiNotReadyError) detailState.value = 'not-ready'
    else detailState.value = 'error'
    stopPoll()
  } finally {
    if (!silent) loading.value = false
  }
}

async function onStop() {
  if (stopDisabledReason.value) return
  try {
    await ElMessageBox.confirm(
      '停止将终止测试流量并进入恢复路径；202 受理只表示恢复中，恢复核验完成才 CLOSED（§7.4）。该操作留痕审计。',
      '停止并恢复',
      { type: 'warning', confirmButtonText: '确认停止', cancelButtonText: '再想想' },
    )
  } catch {
    return // 用户取消
  }
  stopping.value = true
  try {
    const res = await stopDrill(drillId.value, newIdempotencyKey())
    if (res?.alreadyRequested) {
      ElMessage.info(`停止请求此前已受理（异键幂等，零新副作用，DU14）；当前相位 ${res.state ?? '—'}`)
    } else if (res?.replayed) {
      ElMessage.info(`停止请求此前已受理（同键幂等重放）；停止路径 ${res.state ?? '—'}`)
    } else if (res?.state === 'CANCELLING') {
      ElMessage.success('停止请求已受理（202）：注入前取消中（CANCELLING）')
    } else {
      ElMessage.success('停止请求已受理（202）：恢复中（RECOVERING）——受理≠恢复完成，核验完成才 CLOSED')
    }
    await loadDetail(false)
    if (eventsState.value === 'ok') await fetchEventsAfter(lastSeq(), 50) // STOP_REQUESTED 已同步落账
  } catch (e) {
    if (e instanceof ApiNotReadyError && e.status === 403) {
      ElMessage.error('无操作权限（403）：停止命令被拒绝')
    } else if (e instanceof ApiNotReadyError) {
      ElMessage.warning('停止接口不可用（404）：后端版本可能滞后，未产生任何注入')
    } else if (e?.response?.status === 409) {
      // 终态 / RECOVERY_FAILED 占位：服务端文案如实透出（「需处理恢复而非停止」）
      ElMessage.error(e.response.data?.error || '停止冲突（409）')
      await loadDetail(false)
    } else {
      ElMessage.error(e?.response?.data?.error || '停止请求失败，请重试')
    }
  } finally {
    stopping.value = false
  }
}

// 路由 A→B：停轮询、推进 generation 使旧请求作废、清空全部状态后按新身份重拉（PAGE-07）
watch(drillId, (id, old) => {
  if (!id || id === old) return
  stopPoll()
  generation++
  detailIssue.value = false
  eventsIssue.value = false
  lastLoadedAt.value = null
  drill.value = null
  detailState.value = 'loading'
  events.value = []
  eventsHasMore.value = false
  eventsState.value = 'loading'
  expandedSeqs.value = new Set()
  loadDetail(false)
  loadEvents()
})

// 隐藏暂停 / 恢复可见立即刷新（有界轮询纪律）
function onVisibility() {
  if (document.hidden) stopPoll()
  else if (detailState.value === 'ok' && !TERMINAL.has(drill.value?.state)) {
    loadDetail(true)
    startPoll()
  }
}

onMounted(() => {
  loadDetail(false)
  loadEvents()
  startPoll()
  document.addEventListener('visibilitychange', onVisibility)
})
onBeforeUnmount(() => {
  stopPoll()
  document.removeEventListener('visibilitychange', onVisibility)
})
</script>

<style scoped>
.detail-page { display: flex; flex-direction: column; gap: var(--section-gap); }

.head-card { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; padding: 16px var(--card-pad); }
.hd-label { font-size: var(--fs-aux); color: var(--ink-2); }
.hd-value { font-size: var(--fs-section); font-weight: 600; color: var(--head); margin-top: 2px; }
.hd-note { font-size: var(--fs-aux); color: var(--ink-2); margin-top: 2px; }
.hd-stop { color: var(--warn); }

.conn-note { padding: 10px var(--card-pad); font-size: var(--fs-aux); color: var(--warn); }

.timeline-card, .link-card, .events-card { padding: var(--card-pad); }
.tl-title { font-size: var(--fs-section); font-weight: 600; color: var(--head); margin-bottom: 8px; }
.tl-note { font-size: var(--fs-aux); color: var(--ink-2); margin-bottom: 16px; line-height: 1.7; }

.tl-list { list-style: none; }
.tl-item {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 10px 8px; border-bottom: 1px dashed var(--line); border-radius: var(--radius-ctl);
}
.tl-item:last-child { border-bottom: none; }
.tl-item.tl-active { background: var(--brand-soft); }
.tl-item.tl-active .tl-idx { border-color: var(--brand); color: var(--brand); font-weight: 700; }
.tl-item.tl-failed { background: var(--bad-bg); }
.tl-idx {
  flex: none; width: 24px; height: 24px; border-radius: 50%;
  border: 1px solid var(--line-strong); color: var(--ink-2);
  display: inline-flex; align-items: center; justify-content: center;
  font-size: var(--fs-aux); margin-top: 2px;
}
.tl-body { flex: 1; min-width: 0; }
.tl-name { font-size: var(--fs-body); font-weight: 600; color: var(--ink); }
.tl-phase {
  margin-left: 8px; font-size: var(--fs-aux); font-weight: 400; color: var(--ink-2);
  background: var(--bg); border-radius: var(--radius-ctl); padding: 1px 6px;
}
.tl-desc { font-size: var(--fs-aux); color: var(--ink-2); margin-top: 2px; line-height: 1.6; }
.tl-entered { font-size: var(--fs-aux); color: var(--ink-2); margin-top: 2px; }
.tl-state { flex: none; font-size: var(--fs-aux); color: var(--ink-2); padding-top: 4px; }
.tl-st-active { color: var(--brand); font-weight: 700; }
.tl-st-done { color: var(--ok); }
.tl-st-failed { color: var(--bad); }
.mono { font-family: var(--mono, monospace); word-break: break-all; }

.ev-list { list-style: none; display: flex; flex-direction: column; }
.ev-item { display: flex; align-items: flex-start; gap: 12px; padding: 10px 8px; border-bottom: 1px dashed var(--line); }
.ev-item:last-child { border-bottom: none; }
.ev-badge {
  flex: none; font-size: var(--fs-aux); border-radius: 999px; padding: 2px 10px;
  border: 1px solid var(--line-strong); color: var(--ink-2); margin-top: 2px; white-space: nowrap;
}
.ev-b-transition { border-color: var(--brand); color: var(--brand); background: var(--brand-soft); }
.ev-b-stop { border-color: var(--warn); color: var(--warn); }
.ev-b-outcome { border-color: var(--ok); color: var(--ok); }
.ev-body { flex: 1; min-width: 0; }
.ev-meta { display: flex; gap: 12px; flex-wrap: wrap; font-size: var(--fs-aux); color: var(--ink-2); }
.ev-payload {
  margin: 6px 0 0; font-family: var(--mono, monospace); font-size: var(--fs-aux);
  color: var(--ink-2); background: var(--bg); border-radius: var(--radius-ctl);
  padding: 6px 8px; white-space: pre-wrap; word-break: break-all;
}
.pager { display: flex; align-items: center; justify-content: center; gap: 16px; padding: 12px 0 4px; }
.muted { color: var(--ink-2); font-size: var(--fs-aux); }
.loading-box { height: 200px; }

.preview-list { border: 1px solid var(--line); border-radius: var(--radius); overflow: hidden; }
.pv-row { display: flex; gap: 16px; padding: 12px 16px; border-bottom: 1px solid var(--line); }
.pv-row:last-child { border-bottom: none; }
.pv-row dt { flex: none; width: 120px; font-size: var(--fs-body); font-weight: 600; color: var(--ink); }
.pv-row dd { font-size: var(--fs-body); color: var(--ink-2); }
</style>
