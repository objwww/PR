package com.objwww.pr.control.alert.application;

import com.objwww.pr.control.alert.domain.claim.ClaimKind;
import com.objwww.pr.control.alert.domain.claim.ClaimLifecycle;
import com.objwww.pr.control.alert.domain.claim.ClaimStatus;
import com.objwww.pr.control.alert.domain.claim.ClaimStore;
import com.objwww.pr.control.alert.domain.claim.EvidenceBasis;
import com.objwww.pr.control.alert.domain.dag.DependencyType;
import com.objwww.pr.control.alert.domain.dag.TaskEdge;
import com.objwww.pr.control.alert.domain.model.OperatorCommand;
import com.objwww.pr.control.alert.domain.model.RcaRun;
import com.objwww.pr.control.alert.domain.model.RcaRunState;
import com.objwww.pr.control.alert.domain.model.RcaTask;
import com.objwww.pr.control.alert.domain.model.RcaTaskState;
import com.objwww.pr.control.alert.domain.model.RunTrigger;
import com.objwww.pr.control.alert.domain.model.TaskExecutionBinding;
import com.objwww.pr.control.alert.domain.repository.RcaModelCallUsageReader;
import com.objwww.pr.control.alert.domain.repository.RcaRunRepository;
import com.objwww.pr.control.alert.domain.repository.RcaRunTraceReader.SpanRow;
import com.objwww.pr.control.alert.domain.repository.RcaTaskRepository;
import com.objwww.pr.control.alert.domain.repository.TaskEdgeRepository;
import com.objwww.pr.control.alert.domain.repository.TaskExecutionBindingRepository;
import com.objwww.pr.shared.Digest;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * RunQueryService 单测（M5-13）：bucket 由 run+task 状态推导（C-18④）、SLA 面、
 * detail 的路由/进度/DAG 投影（C-18②③：engine/config 读 V25 列，budget 如实 null）、
 * §三.5 多 Agent 透出（role/round 读 V46 绑定、usage 读 V48 账本；旧 run 降级 null）。
 */
class RunQueryServiceTest {

    private static final Instant NOW = Instant.parse("2026-09-08T10:00:00Z");
    private static final Supplier<Instant> CLOCK = () -> NOW;

    private final FakeRuns runs = new FakeRuns();
    private final FakeTasks tasks = new FakeTasks();
    private final FakeEdges edges = new FakeEdges();
    private final FakeBindings bindings = new FakeBindings();
    private final FakeUsage usage = new FakeUsage();
    private final FakeClaims claims = new FakeClaims();
    private final RunQueryService service =
            new RunQueryService(runs, tasks, edges, bindings, usage, claims, CLOCK);

    @Test
    void bucketsDeriveFromRunAndTaskStates() {
        UUID stuckRun = run(RcaRunState.RUNNING);
        task(stuckRun, "METRICS", RcaTaskState.DONE);
        task(stuckRun, "ROOT_CAUSE", RcaTaskState.BLOCKED);
        UUID runningRun = run(RcaRunState.RUNNING);
        task(runningRun, "METRICS", RcaTaskState.RUNNING);
        UUID failedRun = run(RcaRunState.FAILED);
        UUID reviewRun = run(RcaRunState.SUCCEEDED);

        Map<String, Object> out = service.list();

        @SuppressWarnings("unchecked")
        Map<String, Object> buckets =
                (Map<String, Object>) ((Map<String, Object>) out.get("summary")).get("buckets");
        assertThat(buckets).containsEntry("mine", 0)
                .containsEntry("running", 1).containsEntry("stuck", 1)
                .containsEntry("failed", 1).containsEntry("review", 1);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> rows = (List<Map<String, Object>>) out.get("rows");
        assertThat(rows).hasSize(4);
        Map<String, Object> stuck = byBucket(rows, "stuck");
        assertThat(stuck.get("stage")).isEqualTo("BLOCKED");
        assertThat(stuck.get("stageZh")).isEqualTo("卡住");
        assertThat(stuck.get("progress")).isEqualTo("1/2");
        assertThat(stuck.get("blocker")).isEqualTo("ROOT_CAUSE:BLOCKED");
        assertThat(stuck.get("severity")).isNull();
        assertThat(stuck.get("owner")).isNull();
        assertThat(stuck.get("action")).isEqualTo("view");
        assertThat(byBucket(rows, "running").get("stage")).isEqualTo("RUNNING");
        assertThat(out.get("nextCursor")).isNull();
    }

    @Test
    void slaFacesCountOverDeadlineAndOldestReadyWait() {
        UUID overRun = run(RcaRunState.RUNNING);
        task(overRun, "ROOT_CAUSE", RcaTaskState.LEASED, NOW.minus(Duration.ofMinutes(6)));
        UUID readyRun = run(RcaRunState.QUEUED);
        task(readyRun, "METRICS", RcaTaskState.READY, null)
                .readySince(NOW.minus(Duration.ofMinutes(18)));

        Map<String, Object> out = service.list();

        @SuppressWarnings("unchecked")
        Map<String, Object> sla =
                (Map<String, Object>) ((Map<String, Object>) out.get("summary")).get("sla");
        assertThat(sla.get("overSla")).isEqualTo(1);
        assertThat(sla.get("oldestReadyWait")).isEqualTo("18m");
        assertThat(sla.get("projectionLag")).as("无观测面 → 如实 null（C-18③）").isNull();
    }

    @Test
    void detailProjectsRoutingProgressTasksAndEdges() {
        UUID runId = run(RcaRunState.RUNNING);
        UUID metricsId = task(runId, "METRICS", RcaTaskState.DONE).taskId();
        task(runId, "ROOT_CAUSE", RcaTaskState.RUNNING, null)
                .lease("worker-03", 7).attempts(2);
        edges.insert(runId, metricsId, UUID.randomUUID(), DependencyType.REQUIRED);
        UUID edgeTo = UUID.randomUUID();
        edges.insert(runId, edgeTo, UUID.randomUUID(), DependencyType.OPTIONAL);
        runs.routing.put(runId, new RcaRunRepository.RoutingView(
                com.objwww.pr.control.alert.domain.model.RcaEngine.NATIVE,
                "9c1e".repeat(16), "grp:1", 42, null, null, null));

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        @SuppressWarnings("unchecked")
        Map<String, Object> head = (Map<String, Object>) detail.get("run");
        assertThat(head.get("status")).isEqualTo("RUNNING");
        assertThat(head.get("severity")).as("无列 → 如实 null（C-18①）").isNull();
        assertThat(head.get("engine")).isEqualTo("NATIVE");
        assertThat(head.get("config")).isEqualTo("9c1e".repeat(16));
        assertThat(head.get("budget")).as("无读面 → 如实 null（C-18③）").isNull();
        assertThat(head.get("progress")).isEqualTo(Map.of("done", 1, "running", 1, "blocked", 0, "total", 2));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> taskRows = (List<Map<String, Object>>) detail.get("tasks");
        Map<String, Object> rootCause = taskRows.stream()
                .filter(t -> "ROOT_CAUSE".equals(t.get("id"))).findFirst().orElseThrow();
        assertThat(rootCause.get("lease")).isEqualTo(Map.of("worker", "worker-03", "epoch", 7L));
        assertThat(rootCause.get("attempts")).isEqualTo(2);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> edgeRows = (List<Map<String, Object>>) detail.get("edges");
        assertThat(edgeRows).hasSize(2);
        assertThat(edgeRows.get(0).get("source")).isEqualTo("METRICS");
        assertThat(edgeRows.get(1).get("source")).isEqualTo(edgeTo.toString());
    }

    @Test
    void detailFailureBlockFromModelCallLedger() {
        UUID runId = run(RcaRunState.SUCCEEDED);
        usage.failuresByRun.put(runId, List.of(
                new RcaModelCallUsageReader.CallFailure("BILLING_OR_ACTIVATION", 2)));

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        @SuppressWarnings("unchecked")
        Map<String, Object> failure = (Map<String, Object>) detail.get("failure");
        assertThat(failure.get("totalFailed")).isEqualTo(2L);
        assertThat((String) failure.get("reasonZh")).contains("欠费").contains("×2");
        assertThat((String) failure.get("guidanceZh")).contains("充值");
    }

    @Test
    void detailFailureBlockIsNullWhenNoFailedCalls() {
        UUID runId = run(RcaRunState.SUCCEEDED);

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        assertThat(detail.get("failure")).as("零失败账 → null（证据问题不找借口）").isNull();
    }

    @Test
    void detailIsEmptyForUnknownRun() {        assertThat(service.detail(UUID.randomUUID())).isEmpty();
    }

    // ------------------------------------------------ A4：claims 投影 + task name

    @Test
    void detailProjectsClaimsWithFixedKeyMapping() {
        UUID runId = run(RcaRunState.RUNNING);
        task(runId, "ROOT_CAUSE", RcaTaskState.RUNNING);
        UUID activeId = UUID.randomUUID();
        claims.byRun.put(runId, List.of(
                // 乱序入桩：投影必须按 claimKey 字典序重排（与 A1 一致）
                new ClaimStore.ClaimRow(UUID.randomUUID(), runId, "fp-b", "hash-b", "b-key",
                        ClaimStatus.UNKNOWN, EvidenceBasis.SINGLE_SOURCE,
                        ClaimLifecycle.SUPERSEDED, "旧假设", "scope", "10m", 2L,
                        List.of("src"), List.of(), "pv", "dg", null),
                new ClaimStore.ClaimRow(activeId, runId, "fp-a", "hash-a", "a-key",
                        ClaimStatus.TRUE, EvidenceBasis.MULTI_SOURCE_CONFLICT,
                        ClaimLifecycle.ACTIVE, "根因已定", "scope", "10m", 3L,
                        List.of("src"), List.of("ev-1", "ev-2"), "pv", "dg",
                        ClaimKind.ROOT_CAUSE)));

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> claimRows = (List<Map<String, Object>>) detail.get("claims");
        assertThat(claimRows).hasSize(2);
        Map<String, Object> first = claimRows.get(0);
        // 五字段映射逐键断言（写死键名：id/kind/text/code/verdict/current/evidences）
        assertThat(first.get("id")).isEqualTo(activeId.toString());
        assertThat(first.get("kind")).isEqualTo("ROOT_CAUSE");
        assertThat(first.get("text")).isEqualTo("根因已定");
        assertThat(first.get("code")).isEqualTo("a-key");
        assertThat(first.get("verdict")).isEqualTo("TRUE");
        assertThat(first.get("current")).isEqualTo(true);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> evidences =
                (List<Map<String, Object>>) first.get("evidences");
        assertThat(evidences).as("evidences 首版只给 id（ref 原文）")
                .containsExactly(Map.of("id", "ev-1"), Map.of("id", "ev-2"));
        assertThat(first).as("agree 为 mock 遗留无源字段——不给键").doesNotContainKey("agree");

        Map<String, Object> second = claimRows.get(1);
        assertThat(second.get("kind")).as("旧行 kind 无值 → 如实 null").isNull();
        assertThat(second.get("current")).as("current 由 lifecycle 推导（SUPERSEDED → false）")
                .isEqualTo(false);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> taskRows = (List<Map<String, Object>>) detail.get("tasks");
        assertThat(taskRows.get(0).get("name")).as("name = taskKey 显式给键消歧义")
                .isEqualTo("ROOT_CAUSE");
    }

    @Test
    void detailWithoutClaimsProjectsEmptyArrayNotNull() {
        UUID runId = run(RcaRunState.SUCCEEDED);
        task(runId, "METRICS", RcaTaskState.DONE);

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        assertThat(detail.get("claims")).as("无 claim run → 空数组非 null")
                .isEqualTo(List.of());
    }

    // ------------------------------------------------ §三.5 多 Agent 透出（R7-X1/V46 + R7a-1/V48）

    @Test
    void detailProjectsRoleRoundAndUsageFromBindingAndLedger() {
        UUID runId = run(RcaRunState.RUNNING);
        UUID primaryId = task(runId, "PRIMARY_INVESTIGATE", RcaTaskState.RUNNING).taskId();
        UUID delegateId = UUID.randomUUID();
        tasks.rows.put(delegateId, new RcaTask(delegateId, runId, "LOG_ANALYZE",
                RcaTaskState.READY, 10, NOW.minus(Duration.ofMinutes(5)),
                NOW.minus(Duration.ofMinutes(4)), Instant.MAX, null, null, 0, 0, 3,
                NOW.minus(Duration.ofMinutes(5)), NOW, 1));
        UUID parentRequest = UUID.randomUUID();
        bindings.insert(binding(primaryId, runId, 0, "PRIMARY_INVESTIGATE",
                "primary-investigator", "1.2.0", null));
        bindings.insert(binding(delegateId, runId, 1, "LOG_ANALYZE",
                "log-analyst", "0.9.3", parentRequest));
        usage.byRun.put(runId, new RcaModelCallUsageReader.RunUsage(
                3, 1200, 340, 1523000L, 1, "CNY", "pv-2026-09"));

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> taskRows = (List<Map<String, Object>>) detail.get("tasks");
        Map<String, Object> primary = taskRows.stream()
                .filter(t -> "PRIMARY_INVESTIGATE".equals(t.get("id"))).findFirst().orElseThrow();
        assertThat(primary.get("roundId")).isEqualTo(0);
        assertThat(primary.get("roleId")).isEqualTo("primary-investigator");
        assertThat(primary.get("roleVersion")).isEqualTo("1.2.0");
        assertThat(primary.get("parentRequestId")).as("round0 主任务恒 null（V46）").isNull();
        Map<String, Object> delegate = taskRows.stream()
                .filter(t -> "LOG_ANALYZE".equals(t.get("id"))).findFirst().orElseThrow();
        assertThat(delegate.get("roundId")).isEqualTo(1);
        assertThat(delegate.get("roleId")).isEqualTo("log-analyst");
        assertThat(delegate.get("parentRequestId")).isEqualTo(parentRequest.toString());

        @SuppressWarnings("unchecked")
        Map<String, Object> usageBlock = (Map<String, Object>) detail.get("usage");
        assertThat(usageBlock)
                .containsEntry("callCount", 3L).containsEntry("tokensIn", 1200L)
                .containsEntry("tokensOut", 340L).containsEntry("costMicros", 1523000L)
                .containsEntry("usageMissing", 1L).containsEntry("currency", "CNY")
                .containsEntry("pricingVersion", "pv-2026-09");
    }

    @Test
    void detailWithoutBindingsOrModelCallsDegradesToNulls() {
        // 旧版单角色 run（R7 前铸造）：无绑定行、无模型调用账本 → 如实 null，不伪造
        UUID runId = run(RcaRunState.SUCCEEDED);
        task(runId, "HOLMES_INVESTIGATE", RcaTaskState.DONE);

        Map<String, Object> detail = service.detail(runId).orElseThrow();

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> taskRows = (List<Map<String, Object>>) detail.get("tasks");
        Map<String, Object> row = taskRows.get(0);
        assertThat(row.get("roleId")).isNull();
        assertThat(row.get("roleVersion")).isNull();
        assertThat(row.get("parentRequestId")).isNull();
        assertThat(row.get("roundId")).as("存量行 default 0 = round 0（V46）").isEqualTo(0);
        assertThat(detail.get("usage")).as("无行 → null，前端显「无模型调用」而非全 0").isNull();
    }

    private static TaskExecutionBinding binding(UUID taskId, UUID runId, int roundId,
            String taskKey, String roleId, String roleVersion, UUID parentRequestId) {
        return new TaskExecutionBinding(taskId, runId, roundId, taskKey, roleId, roleVersion,
                "a".repeat(64), null, null, List.of(), Map.of(), parentRequestId, true,
                TaskExecutionBinding.FailurePolicy.DEAD_ON_FAILURE, NOW);
    }

    // ------------------------------------------------------------------ fixtures

    private UUID run(RcaRunState state) {
        UUID id = UUID.randomUUID();
        boolean terminal = !state.isActive();
        runs.rows.put(id, new RcaRun(id, UUID.randomUUID(), 0, RunTrigger.INITIAL, state,
                Digest.sha256Of("inv-" + id),
                NOW.minus(Duration.ofMinutes(30)), NOW,
                NOW.minus(Duration.ofMinutes(24)),
                terminal ? NOW.minus(Duration.ofMinutes(5)) : null,
                null));
        return id;
    }

    private TaskBuilder task(UUID runId, String key, RcaTaskState state) {
        return task(runId, key, state, null);
    }

    /** deadlineAt 为 Instant.MAX（永不到期，与真实铸造一致）除非显式给 overDeadline */
    private TaskBuilder task(UUID runId, String key, RcaTaskState state, Instant overDeadline) {
        UUID id = UUID.randomUUID();
        RcaTask t = new RcaTask(id, runId, key, state, 10,
                NOW.minus(Duration.ofMinutes(20)), NOW.minus(Duration.ofMinutes(18)),
                overDeadline != null ? overDeadline : Instant.MAX,
                null, null, 0, 1, 3,
                NOW.minus(Duration.ofMinutes(20)), NOW);
        tasks.rows.put(id, t);
        return new TaskBuilder(id);
    }

    /** 少量字段的二级定制（lease/attempts/readySince），避免主构造重载爆炸 */
    private final class TaskBuilder {
        private final UUID id;

        TaskBuilder(UUID id) {
            this.id = id;
        }

        UUID taskId() {
            return id;
        }

        TaskBuilder lease(String worker, long epoch) {
            RcaTask t = tasks.rows.get(id);
            tasks.rows.put(id, new RcaTask(t.id(), t.runId(), t.taskKey(), t.state(),
                    t.priority(), t.availableAt(), t.readySince(), t.deadlineAt(),
                    worker, NOW.plus(Duration.ofSeconds(30)), epoch,
                    t.attemptCount(), t.maxAttempts(), t.createdAt(), t.updatedAt()));
            return this;
        }

        TaskBuilder attempts(int n) {
            RcaTask t = tasks.rows.get(id);
            tasks.rows.put(id, new RcaTask(t.id(), t.runId(), t.taskKey(), t.state(),
                    t.priority(), t.availableAt(), t.readySince(), t.deadlineAt(),
                    t.leaseOwner(), t.leaseUntil(), t.leaseEpoch(),
                    n, t.maxAttempts(), t.createdAt(), t.updatedAt()));
            return this;
        }

        TaskBuilder readySince(Instant readySince) {
            RcaTask t = tasks.rows.get(id);
            tasks.rows.put(id, new RcaTask(t.id(), t.runId(), t.taskKey(), t.state(),
                    t.priority(), t.availableAt(), readySince, t.deadlineAt(),
                    t.leaseOwner(), t.leaseUntil(), t.leaseEpoch(),
                    t.attemptCount(), t.maxAttempts(), t.createdAt(), t.updatedAt()));
            return this;
        }
    }

    // ------------------------------------------------ WC-5：取消收敛读面（停止进度/原因字段）

    @Test
    void wc5DetailExposesCancelConvergenceFacts() {
        com.objwww.pr.control.alert.application.tool.InFlightToolCancels cancels =
                new com.objwww.pr.control.alert.application.tool.InFlightToolCancels();
        FakeCommands commands = new FakeCommands();
        FakeLedger ledger = new FakeLedger();
        RunQueryService svc = new RunQueryService(runs, tasks, edges, bindings, usage, claims,
                CLOCK, cancels, ledger, commands);

        // 停止中：CANCEL 已 APPLIED（多次取消取最新 appliedAt；PERSISTED 行不冒认）
        // + cancelRun 已通知但 1 个工具等待尚未静默
        UUID stoppingRun = run(RcaRunState.RUNNING);
        task(stoppingRun, "ROOT_CAUSE", RcaTaskState.RUNNING);
        commands.byRun.put(stoppingRun, List.of(
                command(stoppingRun, "cancel-old", OperatorCommand.State.APPLIED,
                        NOW.minus(Duration.ofMinutes(3))),
                command(stoppingRun, "cancel-new", OperatorCommand.State.APPLIED,
                        NOW.minus(Duration.ofMinutes(2))),
                command(stoppingRun, "cancel-still-persisted", OperatorCommand.State.PERSISTED,
                        null)));
        java.util.concurrent.CompletableFuture<Object> inflight =
                new java.util.concurrent.CompletableFuture<>();
        // RV03 句柄 API：注册（QUEUED=在飞事实）→ attach 中断面 → cancelRun 通知
        var inflightHandle = cancels.register(stoppingRun);
        inflightHandle.attach(inflight);
        cancels.cancelRun(stoppingRun);
        ledger.unknownByRun.put(stoppingRun, 2L);

        Map<String, Object> stopping = svc.detail(stoppingRun).orElseThrow();
        @SuppressWarnings("unchecked")
        Map<String, Object> stoppingHead = (Map<String, Object>) stopping.get("run");
        assertThat(stoppingHead.get("terminationRequestedAt"))
                .isEqualTo(NOW.minus(Duration.ofMinutes(2)).toString());
        assertThat(stoppingHead.get("localExecutionState")).isEqualTo("STOPPING");
        assertThat(stoppingHead.get("inflightCount")).isEqualTo(1);
        assertThat(stoppingHead.get("unknownActionCount")).isEqualTo(2L);

        // 已静默：终态 run + 在途清零（unregister 即移除面）
        UUID quiescedRun = run(RcaRunState.CANCELLED);
        task(quiescedRun, "ROOT_CAUSE", RcaTaskState.STALE);
        Map<String, Object> quiesced = svc.detail(quiescedRun).orElseThrow();
        @SuppressWarnings("unchecked")
        Map<String, Object> quiescedHead = (Map<String, Object>) quiesced.get("run");
        assertThat(quiescedHead.get("terminationRequestedAt")).isNull();
        assertThat(quiescedHead.get("localExecutionState")).isEqualTo("QUIESCED");
        assertThat(quiescedHead.get("inflightCount")).isEqualTo(0);
        assertThat(quiescedHead.get("unknownActionCount")).isEqualTo(0L);

        // 旧装配（7 参构造）无取消/账本/命令面：四字段按"无知识"降级，不伪造
        Map<String, Object> legacy = service.detail(stoppingRun).orElseThrow();
        @SuppressWarnings("unchecked")
        Map<String, Object> legacyHead = (Map<String, Object>) legacy.get("run");
        assertThat(legacyHead.get("terminationRequestedAt")).isNull();
        assertThat(legacyHead.get("localExecutionState")).isNull();
        assertThat(legacyHead.get("inflightCount")).isEqualTo(0);
        assertThat(legacyHead.get("unknownActionCount")).isEqualTo(0L);
    }

    private static OperatorCommand command(UUID runId, String key,
            OperatorCommand.State state, Instant appliedAt) {
        return new OperatorCommand(UUID.randomUUID(), runId, OperatorCommand.Type.CANCEL,
                key, 0, Map.of(), state, "operator-1", NOW.minus(Duration.ofMinutes(5)),
                appliedAt);
    }

    private static Map<String, Object> byBucket(List<Map<String, Object>> rows, String bucket) {
        return rows.stream().filter(r -> bucket.equals(r.get("bucket"))).findFirst().orElseThrow();
    }

    // ------------------------------------------------------------------ 内存假

    static final class FakeRuns implements RcaRunRepository {
        final Map<UUID, RcaRun> rows = new LinkedHashMap<>();
        final Map<UUID, RoutingView> routing = new LinkedHashMap<>();

        @Override
        public void insert(RcaRun run) {
            rows.put(run.id(), run);
        }

        // C-61 fake 镜像：无路由记录 = 普通 insert 存量行 = 默认 HOLMES
        @Override
        public boolean existsNativeRunByIncidentId(UUID incidentId) {
            return routing.values().stream().anyMatch(v -> v.engine()
                    == com.objwww.pr.control.alert.domain.model.RcaEngine.NATIVE);
        }

        @Override
        public Optional<RcaRun> findByIdForUpdate(UUID id) {
            return Optional.ofNullable(rows.get(id));
        }

        @Override
        public Optional<RcaRun> findById(UUID id) {
            return Optional.ofNullable(rows.get(id));
        }

        @Override
        public boolean update(RcaRun run) {
            return rows.containsKey(run.id());
        }

        @Override
        public Optional<RcaRun> findActiveByIncidentId(UUID incidentId) {
            return Optional.empty();
        }

        @Override
        public List<RcaRun> findAll() {
            return rows.values().stream()
                    .sorted(Comparator.comparing(RcaRun::createdAt).reversed()
                            .thenComparing(RcaRun::id))
                    .toList();
        }

        @Override
        public Optional<RoutingView> findRoutingById(UUID id) {
            return Optional.ofNullable(routing.get(id));
        }

        @Override
        public java.util.OptionalLong currentRevision(UUID id) {
            return rows.containsKey(id) ? java.util.OptionalLong.of(0) : java.util.OptionalLong.empty();
        }
    }

    static final class FakeTasks implements RcaTaskRepository {
        final Map<UUID, RcaTask> rows = new LinkedHashMap<>();

        @Override
        public void insert(RcaTask task) {
            rows.put(task.id(), task);
        }

        @Override
        public Optional<RcaTask> claimNext(String owner, Instant now, Duration lease) {
            return Optional.empty();
        }

        @Override
        public boolean requireCurrentLease(UUID id, String owner, long leaseEpoch) {
            return false;
        }

        @Override
        public boolean update(RcaTask task) {
            return rows.containsKey(task.id());
        }

        @Override
        public void heartbeat(UUID id, String owner, long leaseEpoch, Instant now, Duration extend) {
        }

        @Override
        public List<RcaTask> findExpiredLeased(Instant now) {
            return List.of();
        }

        @Override
        public Optional<RcaTask> findById(UUID id) {
            return Optional.ofNullable(rows.get(id));
        }

        @Override
        public List<RcaTask> findByRunId(UUID runId) {
            return rows.values().stream()
                    .filter(t -> t.runId().equals(runId))
                    .sorted(Comparator.comparing(RcaTask::id))
                    .toList();
        }

        @Override
        public boolean transitionState(UUID id, RcaTaskState from, RcaTaskState to) {
            return false;
        }

        @Override
        public int countQueued() {
            return 0;
        }
    }

    static final class FakeEdges implements TaskEdgeRepository {
        private final Map<UUID, List<TaskEdge>> byRun = new LinkedHashMap<>();

        @Override
        public void insert(UUID runId, UUID fromTaskId, UUID toTaskId, DependencyType dependencyType) {
            byRun.computeIfAbsent(runId, k -> new ArrayList<>())
                    .add(new TaskEdge(fromTaskId.toString(), toTaskId.toString(), dependencyType));
        }

        @Override
        public List<TaskEdge> findByRunId(UUID runId) {
            return byRun.getOrDefault(runId, List.of());
        }
    }

    static final class FakeBindings implements TaskExecutionBindingRepository {
        final Map<UUID, TaskExecutionBinding> byTask = new LinkedHashMap<>();

        @Override
        public void insert(TaskExecutionBinding binding) {
            byTask.put(binding.taskId(), binding);
        }

        @Override
        public Optional<TaskExecutionBinding> findByTask(UUID taskId) {
            return Optional.ofNullable(byTask.get(taskId));
        }

        @Override
        public List<TaskExecutionBinding> findByRun(UUID runId) {
            return byTask.values().stream()
                    .filter(b -> b.runId().equals(runId))
                    .sorted(Comparator.comparingInt(TaskExecutionBinding::roundId)
                            .thenComparing(TaskExecutionBinding::taskKey))
                    .toList();
        }
    }

    static final class FakeUsage implements RcaModelCallUsageReader {
        final Map<UUID, RunUsage> byRun = new LinkedHashMap<>();
        final Map<UUID, List<CallFailure>> failuresByRun = new LinkedHashMap<>();

        @Override
        public Optional<RunUsage> summarizeByRun(UUID runId) {
            return Optional.ofNullable(byRun.get(runId));
        }

        @Override
        public List<CallFailure> failuresByRun(UUID runId) {
            return failuresByRun.getOrDefault(runId, List.of());
        }
    }

    /** A4 内存 ClaimStore 桩（findByRunId 直返入桩行，排序归服务层验证） */
    static final class FakeClaims implements ClaimStore {
        final Map<UUID, List<ClaimRow>> byRun = new LinkedHashMap<>();

        @Override
        public ClaimAppendResult append(UUID runId,
                com.objwww.pr.control.alert.domain.claim.ClaimVerdict verdict) {
            throw new UnsupportedOperationException();
        }

        @Override
        public long markUnresolved(UUID runId,
                com.objwww.pr.control.alert.domain.claim.ClaimIdentity identity,
                String policyVersion) {
            throw new UnsupportedOperationException();
        }

        @Override
        public List<ClaimRow> findByRunId(UUID runId) {
            return byRun.getOrDefault(runId, List.of());
        }
    }

    /** WC-5 内存命令桩：只有 findByRunAndType 读面（读面测试唯一入口） */
    static final class FakeCommands
            implements com.objwww.pr.control.alert.domain.repository.OperatorCommandRepository {
        final Map<UUID, List<OperatorCommand>> byRun = new LinkedHashMap<>();

        @Override
        public void insert(OperatorCommand command) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Optional<OperatorCommand> find(UUID runId, OperatorCommand.Type type,
                String idempotencyKey) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean updateState(UUID id, OperatorCommand.State state, Instant appliedAt) {
            throw new UnsupportedOperationException();
        }

        @Override
        public List<OperatorCommand> findByRunAndType(UUID runId, OperatorCommand.Type type) {
            return byRun.getOrDefault(runId, List.of());
        }
    }

    /** WC-5 内存账本桩：只有 countByRunAndState 读面 */
    static final class FakeLedger
            implements com.objwww.pr.control.alert.domain.tool.RcaToolInvocationLedger {
        final Map<UUID, Long> unknownByRun = new LinkedHashMap<>();

        @Override
        public void open(InvocationIdentity identity) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean succeed(UUID operationId) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean fail(UUID operationId,
                com.objwww.pr.control.alert.domain.tool.ToolInvocationState terminal,
                com.objwww.pr.control.alert.domain.tool.ToolReasonCode reasonCode) {
            throw new UnsupportedOperationException();
        }

        @Override
        public long countByRunAndState(UUID runId,
                com.objwww.pr.control.alert.domain.tool.ToolInvocationState state) {
            return state == com.objwww.pr.control.alert.domain.tool.ToolInvocationState.UNKNOWN
                    ? unknownByRun.getOrDefault(runId, 0L) : 0L;
        }
    }

    // ------------------------------------------------ 3.17 Trace 瀑布（trace 读面）

    /** 三层 span 假读面：按 run 给固定行（task/model/tool 各一） */
    private static class FakeTrace implements com.objwww.pr.control.alert.domain.repository.RcaRunTraceReader {
        final Map<UUID, List<SpanRow>> byRun = new LinkedHashMap<>();

        @Override
        public List<SpanRow> spansByRun(UUID runId) {
            return byRun.getOrDefault(runId, List.of());
        }
    }

    @Test
    void traceProjectsSpansAndSummaryFromReader() {
        UUID runId = run(RcaRunState.SUCCEEDED);
        FakeTrace traceReader = new FakeTrace();
        UUID taskId = UUID.randomUUID();
        traceReader.byRun.put(runId, List.of(
                new SpanRow("task", UUID.randomUUID(), taskId, "PRIMARY_INVESTIGATE", 1,
                        "SUCCEEDED", "2026-09-08T09:58:00Z", "2026-09-08T09:59:00Z",
                        null, null, null, null, null, null, null,
                        "worker-a", 1, null),
                new SpanRow("model", UUID.randomUUID(), taskId, "primary-investigator", 3,
                        "SUCCESS", "2026-09-08T09:58:10Z", null,
                        4200L, "deepseek-v4", 300, 120, 420, 15000L, null,
                        null, null, "primary-investigator"),
                new SpanRow("model", UUID.randomUUID(), taskId, "primary-investigator", 4,
                        "FAILED", "2026-09-08T09:58:30Z", null,
                        null, null, null, null, null, null, "OUTPUT_BUDGET_EXHAUSTED",
                        null, null, "primary-investigator"),
                new SpanRow("tool", UUID.randomUUID(), taskId, "logs.query", 2,
                        "SUCCESS", "2026-09-08T09:58:20Z", "2026-09-08T09:58:25Z",
                        null, null, null, null, null, null, null,
                        null, null, null)));
        RunQueryService withTrace = new RunQueryService(runs, tasks, edges, bindings,
                usage, claims, CLOCK, null, null, null, traceReader);

        Map<String, Object> trace = withTrace.trace(runId).orElseThrow();

        assertThat(((Map<?, ?>) trace.get("run")).get("status")).isEqualTo("SUCCEEDED");
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> spans = (List<Map<String, Object>>) trace.get("spans");
        assertThat(spans).hasSize(4);
        assertThat(spans.get(0)).containsEntry("kind", "task").containsEntry("label", "PRIMARY_INVESTIGATE");
        @SuppressWarnings("unchecked")
        Map<String, Object> summary = (Map<String, Object>) trace.get("summary");
        assertThat(summary).containsEntry("taskSpans", 1L)
                .containsEntry("modelSpans", 2L)
                .containsEntry("toolSpans", 1L)
                .containsEntry("tokensTotal", 420L)
                .containsEntry("tokenMissing", 1L)
                .containsEntry("costMicros", 15000L);
    }

    @Test
    void traceDegradesToEmptySpansWithoutReaderAndUnknownRunIsEmpty() {
        UUID runId = run(RcaRunState.SUCCEEDED);
        task(runId, "PRIMARY_INVESTIGATE", RcaTaskState.DONE);

        // 字段级 service = 7 参构造（无 trace 读面）→ span 空表如实，汇总全零
        Map<String, Object> trace = service.trace(runId).orElseThrow();
        assertThat((List<?>) trace.get("spans")).isEmpty();
        @SuppressWarnings("unchecked")
        Map<String, Object> summary = (Map<String, Object>) trace.get("summary");
        assertThat(summary).containsEntry("taskSpans", 0L)
                .containsEntry("modelSpans", 0L)
                .containsEntry("toolSpans", 0L)
                .containsEntry("tokensTotal", 0L)
                .containsEntry("tokenMissing", 0L)
                .containsEntry("costMicros", null);
        assertThat(service.trace(UUID.randomUUID())).isEmpty();
    }
}
