package com.objwww.pr.control;

import com.objwww.pr.control.domain.ai.CostCalculation;
import com.objwww.pr.control.domain.ai.ModelCallContext;
import com.objwww.pr.control.domain.ai.ModelCallFailure;
import com.objwww.pr.control.domain.ai.ModelCallLedgerRepository;
import com.objwww.pr.control.domain.ai.ModelGatewayPort;
import com.objwww.pr.control.domain.ai.ModelRoute;
import com.objwww.pr.control.domain.ai.ModelRouteIdentity;
import com.objwww.pr.control.domain.ai.ModelStepBudgetGuard;
import com.objwww.pr.control.domain.ai.PricingService;
import com.objwww.pr.control.domain.ai.RouteDecision;
import com.objwww.pr.control.domain.ai.RoutedModelResult;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Control 侧静态架构卡点（L0）。
 * 普通 @Test + ClassFileImporter（本环境 @ArchTest 字段发现不生效，沿用既有惯例）。
 *
 * <p>AM1-T00 清障后：PR 域规则（checkpoint 契约/review 解析/publisher 隔离等）随死代码删除，
 * 保留 M3 模型治理的 L0 规则；AM1 告警域新规则（AFT-A01~A05）由 T09 增补。
 */
class ControlArchitectureTest {

    private static JavaClasses classes;

    @BeforeAll
    static void importClasses() {
        classes = new ClassFileImporter()
                .withImportOption(com.tngtech.archunit.core.importer.ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
                .importPackages("com.objwww.pr.control");
    }

    /** AFT-01：domain 黑名单——Spring/模型 SDK/JDBC/GitHub SDK/HTTP 客户端一律禁入 */
    @Test
    void domainHasNoFrameworkOrSdkDependency() {
        noClasses().that().resideInAPackage("..control.domain..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..",      // 框架
                        "org.springframework.ai..", // 模型 SDK（上单条已覆盖，单列只为可读性）
                        "java.sql..",               // JDBC
                        "com.github..", "org.kohsuke.github..", // GitHub SDK
                        "org.apache.http..", "java.net.http..") // HTTP 客户端也不许进 domain
                .check(classes);
    }

    /**
     * AFT-A01（AM1 §3.1/T02 验收）：告警域 domain 零框架依赖——Spring/Jakarta/JDBC/HTTP/JUnit
     * 一律禁入；shared-kernel 通用件允许。<b>jackson 放行随 BA-22 清账（2026-09-12）废止</b>：
     * EvidencePackageValidator/EvidencePackageV2 已迁移中立树（解析归 application 层
     * EvidencePackageJsonCodec），domain 零 Jackson，jackson 禁项并入 am4 全域规则。
     */
    @Test
    void alertDomainHasNoFrameworkDependency() {
        noClasses().that().resideInAPackage("..control.alert.domain..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "jakarta..",
                        "java.sql..", "org.apache.http..", "java.net.http..",
                        "org.junit..", "com.fasterxml..")
                .check(classes);
    }

    /**
     * INV-AM4-1（AM4 §3.0 R3）：AM4 新增 domain 子包（dag/tool/budget/claim，
     * 2026-09-07 M4-23 批次起扩 evidence/event）零框架——
     * Spring/Jackson/JDBC/HTTP 一律禁入（InternalCanonicalJsonV1 自实现规范化正是为了不引 Jackson）。
     *
     * <p>方法名说明：任务原拟名 alertDomainHasNoFrameworkDependency 与既有 AFT-A01 方法重名，
     * 故命名 am4AlertDomainZeroFrameworkDependency。
     *
     * <p>红绿留证（2026-09-05，mvn -pl control-app -am test -Dtest=... 本方法）：
     * <ul>
     *   <li>红：把 resideInAnyPackage 放宽为 "..control.alert.domain.." 后运行——
     *       因既有 EvidencePackageValidator 调用 com.fasterxml.jackson.databind.*
     *       而失败（ArchUnit 报 25 处违规，Tests run: 1, Failures: 1），
     *       证明规则对 Jackson 依赖有判别力；</li>
     *   <li>绿：收窄到 AM4 四子包后通过；既有 AFT-A01（允许 jackson）保持原状不动。</li>
     * </ul>
     * 覆盖面扩展（2026-09-07，V16/V14 批次落码后的收口）：AM4 新建的 evidence/event
     * 子包加入零框架面（两包现状零 Jackson/Spring，规则扩面即绿——预防性收紧，
     * 非违规驱动）。
     *
     * <p>BA-22 清账收口（2026-09-12）：覆盖面扩至<b>全 alert.domain</b>——
     * EvidencePackageValidator/EvidencePackageV2 已迁移中立树（唯一阻塞项清除，
     * 前置全量 grep 零 Jackson 残余）；AFT-A01 同步废止 jackson 放行并并入禁项，
     * 两规则不再语义打架。
     */
    @Test
    void am4AlertDomainZeroFrameworkDependency() {
        noClasses().that().resideInAPackage("..control.alert.domain..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /**
     * M4-14（AM4 落码方案 v1.3 任务行）："禁运行时网络下载插件"的结构卡点——
     * 工具注册/调度面（application.tool：Registry/Gateway/Executor 契约）禁触一切
     * 网络 API；网络客户端只允许出现在具体工具执行器实现（M4-27+ 的 infra 面与
     * WireMock 测试）中，经构造注入进 Registry。配合 Registry 构造后不可变（无运行时
     * 注册 API），运行期装载插件在网络面上不可能。
     */
    @Test
    void toolGatewaySurfaceNeverTouchesNetworkApis() {
        noClasses().that().resideInAPackage("..control.alert.application.tool..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "java.net.http..", "org.apache.http..", "okhttp3..")
                .check(classes);
    }

    /**
     * B4/INV-AM6-9（落码方案 :248 "有规无则"补钉）：canary 样本写入唯一入口 =
     * 生产采集适配器 CanaryEvidenceSampleCollector（LIVE_CANARY 必须可追到生产事实，
     * 禁脚本补数）。insert 的调用点只许在 release.application 内（仓储实现类是
     * implements 非 call，窗口任务只读）；RcaRunOrchestrator 等调查面只经适配器。
     */
    @Test
    void canarySampleInsertOnlyThroughCollector() {
        noClasses().that().resideOutsideOfPackage("..control.release.application..")
                .should().callMethod(
                        com.objwww.pr.control.release.domain.repository.CanaryEvidenceSampleRepository.class,
                        "insert",
                        com.objwww.pr.control.release.domain.repository.CanaryEvidenceSampleRepository.SampleRow.class)
                .check(classes);
    }

    /**
     * INV-AM5-1 / M5-01：AM5 数据集域模型与端口（eval.domain.model /
     * eval.domain.port）零框架——Spring/Jackson/JDBC/HTTP 一律禁入；三适配器落
     * infrastructure.adapter（纯转换亦不触网），JSON 落库面归
     * infrastructure.persistence（PostgresDatasetVersionRepository）。
     * 预防性收紧（非违规驱动），沿 am4AlertDomainZeroFrameworkDependency 扩面惯例。
     */
    @Test
    void am5DatasetDomainZeroFrameworkDependency() {
        noClasses().that().resideInAnyPackage("..control.eval.domain.model..",
                        "..control.eval.domain.port..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /**
     * M5-09：新顶层包 release 域模型（release.domain.model + repository 端口）零框架
     * ——Spring/Jackson/JDBC/HTTP 一律禁入（ConfigBundle 的 canonical JSON 复用
     * InternalCanonicalJsonV1 自实现规范化，正是为了不引 Jackson；落库面归
     * infrastructure.persistence）。预防性收紧，沿 am5Dataset 规则惯例。
     */
    @Test
    void am5ReleaseDomainZeroFrameworkDependency() {
        noClasses().that().resideInAnyPackage("..control.release.domain.model..",
                        "..control.release.domain.repository..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /**
     * M5-11：新顶层包 ops 域模型（ops.domain.model + statemachine + repository 端口）
     * 零框架——OperatorCase 聚合/状态机的 jsonb 投影映射归 infrastructure.persistence
     * （release 域同惯例）。
     */
    @Test
    void am5OpsDomainZeroFrameworkDependency() {
        noClasses().that().resideInAnyPackage("..control.ops.domain.model..",
                        "..control.ops.domain.statemachine..",
                        "..control.ops.domain.repository..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /**
     * M6-01 ⑩：release.domain.service 扩面零框架（M5-10 CanaryBucketer 与 M6-01
     * CanaryWindowEvaluator 所在子包；Evaluator 的 Map 载荷刻意不引 Jackson——
     * jsonb 序列化归 infrastructure.persistence）。预防性收紧，沿 AM5 惯例。
     */
    @Test
    void am6ReleaseDomainServiceZeroFrameworkDependency() {
        noClasses().that().resideInAPackage("..control.release.domain.service..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /**
     * M6-01 ⑩：NATIVE 执行面禁触 Holmes 基建——Strangler 隔离的结构卡点：
     * infrastructure.nativeexec 对 holmesgpt 客户端/执行器零依赖是 M6-07
     * 「代码引用面归零」的进程内前提（回切 = 路由面职责，不是执行面纠缠）。
     */
    @Test
    void nativeExecutorNeverDependsOnHolmesInfrastructure() {
        noClasses().that().resideInAPackage("..control.infrastructure.nativeexec..")
                .should().dependOnClassesThat().resideInAPackage(
                        "..control.infrastructure.holmes..")
                .check(classes);
    }

    /**
     * M6-01 ⑩（INV-AM6-5 静态边界）：影子/回放工具面不得触证据分级类型——
     * LIVE_CANARY 只归生产采集适配器构造，DRILL/REPLAY 语义由采集面标注；
     * 工具面（ReadOnlyToolFace/ReplayToolGateway 族）与分级正交，引用即语义泄漏。
     */
    @Test
    void replayAndShadowFaceNeverTouchesEvidenceClassTypes() {
        noClasses().that().resideInAPackage("..control.alert.application.replay..")
                .should().dependOnClassesThat().haveFullyQualifiedName(
                        "com.objwww.pr.control.release.domain.model.CanaryEvidenceClass")
                .check(classes);
    }

    /**
     * M6-05（INV-AM6-5，落码方案 M6-05 节）：Holmes Shadow Sampler 类无
     * reports/publication/outbox 引用——抽样入队面是纯 V34 工作行写面，零发布
     * 纪律静态钉死（影子链永不铸报告/发布/通知）。
     */
    @Test
    void holmesShadowSamplerHasNoReportPublicationOrOutboxReference() {
        noClasses().that().haveSimpleName("HolmesShadowSampler")
                .or().haveSimpleName("HolmesShadowScheduler")
                .should().dependOnClassesThat().haveSimpleNameStartingWith("RcaReport")
                .orShould().dependOnClassesThat().haveSimpleNameContaining("Publication")
                .orShould().dependOnClassesThat().haveSimpleNameContaining("Outbox")
                .orShould().dependOnClassesThat().haveSimpleNameContaining("NotifyOutbox")
                .check(classes);
    }

    /**
     * M7-12（AM7 §11 静态架构）：值班域 domain 零框架——Spring/Jackson/JDBC/HTTP/
     * Jakarta 一律禁入（RotationMath/DutyResolver/快照模型全部纯函数，快照序列化归
     * interfaces/infrastructure 面）。预防性收紧，沿 am5Ops 规则惯例。
     */
    @Test
    void am7DutyDomainZeroFrameworkDependency() {
        noClasses().that().resideInAPackage("..control.ops.duty.domain..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "com.fasterxml..",
                        "java.net.http..", "java.sql..",
                        "jakarta..", "org.apache.http..")
                .check(classes);
    }

    /** AFT-20（M3；§4.2）：故障分类与路由决策是封闭类型；Router/Gateway 决策 switch 无 default 兜底。 */
    @Test
    void failureAndDecisionTypesAreSealedWithNoDefaultBranch() throws Exception {
        assertThat(ModelCallFailure.class.isSealed()).as("ModelCallFailure 必须 sealed").isTrue();
        assertThat(RouteDecision.class.isSealed()).as("RouteDecision 必须 sealed").isTrue();
        for (String file : new String[]{
                "src/main/java/com/objwww/pr/control/domain/ai/ModelRouter.java",
                "src/main/java/com/objwww/pr/control/application/ModelGateway.java"}) {
            assertThat(java.nio.file.Files.readString(java.nio.file.Path.of(file)))
                    .as("%s 的决策 switch 不得有 default 兜底分支", file)
                    .doesNotContainPattern("(?m)^\\s*default\\s*[:>-]");
        }
    }

    /** AFT-21 重写（M3 I32）：预算门控类不得依赖成本类型；反射断言字段与方法签名无成本/价格类型。 */
    @Test
    void budgetAndGateClassesDoNotDependOnCostTypes() {
        noClasses().that().haveSimpleName("ModelStepBudgetGuard")
                .should().dependOnClassesThat().haveSimpleName("CostCalculation")
                .orShould().dependOnClassesThat().haveSimpleName("PricingService")
                .check(classes);
        for (java.lang.reflect.Method m : ModelStepBudgetGuard.class.getDeclaredMethods()) {
            assertThat(m.getReturnType()).isNotIn(CostCalculation.class, PricingService.class);
            assertThat(m.getParameterTypes()).doesNotContain(CostCalculation.class, PricingService.class);
        }
        for (Field f : ModelStepBudgetGuard.class.getDeclaredFields()) {
            assertThat(f.getType()).isNotIn(CostCalculation.class, PricingService.class);
        }
    }

    /** AFT-24（M3 §3.1）：domain/ai 零 Spring AI、HTTP client、JDBC、Spring Retry 依赖。 */
    @Test
    void domainAiHasNoFrameworkHttpJdbcOrRetryDependency() {
        noClasses().that().resideInAPackage("..control.domain.ai..")
                .should().dependOnClassesThat().resideInAnyPackage(
                        "org.springframework..", "org.springframework.retry..",
                        "java.net.http..", "org.apache.http..", "java.sql..")
                .check(classes);
    }

    /**
     * AFT-25（M3 §3.1）：调用上下文显式传递——存活模块 src/main 全库禁止
     * ThreadLocal/InheritableThreadLocal 使用形态（ThreadLocalRandom 是退避抖动随机源，
     * 不传递上下文，豁免）。surefire 工作目录 = 模块 basedir。
     */
    @Test
    void noThreadLocalContextPassingAnywhere() throws Exception {
        for (String module : new String[]{"src/main/java", "../shared-kernel/src/main/java"}) {
            try (java.util.stream.Stream<java.nio.file.Path> stream =
                         java.nio.file.Files.walk(java.nio.file.Path.of(module))) {
                for (java.nio.file.Path p : stream.filter(f -> f.toString().endsWith(".java")).toList()) {
                    assertThat(java.nio.file.Files.readString(p))
                            .as("%s 不得使用 ThreadLocal 传递上下文", p)
                            .doesNotContain("ThreadLocal<")
                            .doesNotContain("ThreadLocal.withInitial")
                            .doesNotContain("new ThreadLocal")
                            .doesNotContain("InheritableThreadLocal");
                }
            }
        }
    }

    /**
     * AFT-26（M3 I29）：账本仓储写方法封闭集 + 无旁路 SQL——ModelCallLedgerRepository 的方法集
     * 精确等于 {insertStarted, completeTerminalSuccess, completeTerminalFailure,
     * markUnknownOlderThan}（无通用 update/delete）；control src/main 中表名
     * model_call_ledger 只允许出现在 PostgresModelCallLedgerRepository（唯一 SQL 落点）与
     * ControlSelfCheck（DB 权限探针按表名断言，非 SQL）。
     */
    @Test
    void ledgerRepositoryWriteSurfaceIsClosedAndNoBypassSql() throws Exception {
        assertThat(java.util.Arrays.stream(ModelCallLedgerRepository.class.getDeclaredMethods())
                .map(java.lang.reflect.Method::getName)
                .collect(java.util.stream.Collectors.toSet()))
                .containsExactlyInAnyOrder("insertStarted", "completeTerminalSuccess",
                        "completeTerminalFailure", "markUnknownOlderThan");
        try (java.util.stream.Stream<java.nio.file.Path> stream =
                     java.nio.file.Files.walk(java.nio.file.Path.of("src/main/java"))) {
            for (java.nio.file.Path p : stream.filter(f -> f.toString().endsWith(".java")).toList()) {
                if (p.endsWith("PostgresModelCallLedgerRepository.java")
                        || p.endsWith("ControlSelfCheck.java")) {
                    continue;
                }
                assertThat(java.nio.file.Files.readString(p))
                        .as("%s 不得出现 model_call_ledger 旁路 SQL", p)
                        .doesNotContain("model_call_ledger");
            }
        }
    }

    /**
     * AFT-28（M3 §4.11）：路由身份/故障/账本/上下文类型的字段集不得包含密钥材料字段。
     * usage token 计数（promptTokens 等）是计费用量不是密钥材料，不在禁令内。
     */
    @Test
    void governanceTypesHaveNoSecretMaterialFields() {
        Set<String> names = new HashSet<>();
        Set<Class<?>> seen = new HashSet<>();
        for (Class<?> type : new Class<?>[]{
                ModelRoute.class, ModelRouteIdentity.class,
                com.objwww.pr.control.domain.ai.ModelCallLedgerEntry.class,
                RoutedModelResult.class,
                com.objwww.pr.control.domain.ai.RouteCallOutcome.class,
                ModelCallContext.class, RouteDecision.class, ModelCallFailure.class}) {
            collectFieldNames(type, names, seen);
            for (Class<?> nested : type.getDeclaredClasses()) {
                collectFieldNames(nested, names, seen);
            }
        }
        assertThat(names)
                .as("治理类型字段名不得含密钥材料语义，实际: %s", names)
                .noneMatch(n -> n.matches(".*(apikey|api_key|authorization|bearer|secret"
                        + "|password|privatekey).*"));
    }

    /** AFT-30（M3 CT-45 静态面）：Gateway/RouteClient 实现及重试等待方法不得标注 @Transactional。 */
    @Test
    void gatewayAndRouteClientAreNotTransactional() {
        for (Class<?> type : new Class<?>[]{
                com.objwww.pr.control.application.ModelGateway.class,
                com.objwww.pr.control.infrastructure.model.SpringAiRouteClient.class}) {
            assertThat(type.isAnnotationPresent(
                    org.springframework.transaction.annotation.Transactional.class))
                    .as("%s 类级不得标 @Transactional", type.getSimpleName())
                    .isFalse();
            for (java.lang.reflect.Method m : type.getDeclaredMethods()) {
                assertThat(m.isAnnotationPresent(
                        org.springframework.transaction.annotation.Transactional.class))
                        .as("%s.%s 不得标 @Transactional", type.getSimpleName(), m.getName())
                        .isFalse();
            }
        }
    }

    /** AFT-31（M3 §4.4）：ModelGatewayPort.complete 签名必须携带调用上下文（deadline/取消/租约活性）。 */
    @Test
    void gatewayPortCompleteCarriesCallContext() {
        assertThat(ModelGatewayPort.class.getDeclaredMethods()).hasSize(1);
        assertThat(ModelGatewayPort.class.getDeclaredMethods()[0].getParameterTypes())
                .contains(ModelCallContext.class);
    }

    /** 反射断言：给定类型及其嵌套项目内字段类型的字段名集合，无凭证/寻址语义 */
    static void assertNoCredentialFields(Class<?>... schemaTypes) {
        Set<String> names = new HashSet<>();
        for (Class<?> type : schemaTypes) {
            collectFieldNames(type, names, new HashSet<>());
        }
        assertThat(names).noneMatch(n -> n.contains("token") || n.contains("url")
                || n.contains("permission") || n.contains("secret")
                || n.contains("password") || n.contains("credential") || n.contains("apikey"));
    }

    private static void collectFieldNames(Class<?> type, Set<String> names, Set<Class<?>> seen) {
        if (!seen.add(type)) {
            return;
        }
        for (Field f : type.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) {
                continue;
            }
            names.add(f.getName().toLowerCase(Locale.ROOT));
            Class<?> ft = f.getType();
            // 只递归项目内类型（JDK/第三方类型的字段不属于 schema 契约）
            if (!ft.isPrimitive() && !ft.isEnum()
                    && ft.getPackageName().startsWith("com.objwww")) {
                collectFieldNames(ft, names, seen);
            }
        }
    }
}
