package com.objwww.pr.control.alert.application.agent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.objwww.pr.control.alert.application.DagExecutionService;
import com.objwww.pr.control.alert.application.DeterministicSupervisor;
import com.objwww.pr.control.alert.application.PlanCompiler;
import com.objwww.pr.control.alert.application.RunBudgetGate;
import com.objwww.pr.control.alert.domain.agent.AgentPhase;
import com.objwww.pr.control.alert.domain.agent.AgentProfile;
import com.objwww.pr.control.alert.domain.agent.PrimaryCheckpoint;
import com.objwww.pr.control.alert.domain.agent.PrimaryDecision;
import com.objwww.pr.control.alert.domain.agent.RcaModelCallException;
import com.objwww.pr.control.alert.domain.agent.RoleRuntimeKind;
import com.objwww.pr.control.alert.domain.budget.BudgetKind;
import com.objwww.pr.control.alert.domain.dag.DependencyType;
import com.objwww.pr.control.alert.domain.dag.TaskEdge;
import com.objwww.pr.control.alert.domain.evidence.EvidenceEnvelope;
import com.objwww.pr.control.alert.domain.evidence.EvidenceRepository;
import com.objwww.pr.control.alert.domain.model.RcaRun;
import com.objwww.pr.control.alert.domain.model.RcaRunState;
import com.objwww.pr.control.alert.domain.model.RcaTask;
import com.objwww.pr.control.alert.domain.model.RcaTaskState;
import com.objwww.pr.control.alert.domain.model.RunTrigger;
import com.objwww.pr.control.alert.domain.model.TaskExecutionBinding;
import com.objwww.pr.control.alert.domain.repository.TaskEdgeRepository;
import com.objwww.pr.control.alert.infrastructure.InMemoryRunBudgetLedger;
import com.objwww.pr.control.alert.support.AlertInMemoryStores;
import com.objwww.pr.control.application.ModelGateway;
import com.objwww.pr.control.domain.ai.FaultScope;
import com.objwww.pr.control.domain.ai.ModelCallFailure;
import com.objwww.pr.control.domain.ai.ModelCallLedgerEntry;
import com.objwww.pr.control.domain.ai.ModelCallLedgerRepository;
import com.objwww.pr.control.domain.ai.ModelGatewayParams;
import com.objwww.pr.control.domain.ai.ModelRequest;
import com.objwww.pr.control.domain.ai.ModelRoute;
import com.objwww.pr.control.domain.ai.PricingService;
import com.objwww.pr.control.domain.ai.RouteCallOutcome;
import com.objwww.pr.control.domain.ai.RouteClientPort;
import com.objwww.pr.control.domain.ai.TokenUsage;
import com.objwww.pr.control.domain.service.ExecutionLedger;
import com.objwww.pr.shared.Digest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * R7-X2 单测（v2.1 §十一.1，假件面零真网）：运行器目录按 runtime_kind 解析——
 * <b>第四个同运行器角色纯配置可执行的证明</b>（RX01：新增 Profile 即被执行，零新
 * Java 分派）；未部署运行器类型/未知角色显式拒绝（RX03，CAPABILITY_UNAVAILABLE）；
 * BoundedLlmRoleRunner 单步语义（等待零触网/TOOL_CALL 越权计步/FINAL 准入落检查点/
 * 步数耗尽确定性兜底 FINAL 零模型调用/不可解析计步重驱）。
 */
class R7RoleRunnerTest {

    private static final Instant NOW = Instant.parse("2026-09-11T09:00:00Z");
    private static final Clock CLOCK = Clock.fixed(NOW, ZoneOffset.UTC);
    private static final ModelRoute ROUTE =
            new ModelRoute("route-rca", "model-rca", "ep-rca", "quota-rca", "cred-rca", null);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final AlertInMemoryStores stores = new AlertInMemoryStores();
    private final EdgeStore edges = new EdgeStore();
    private final ScriptedRouteClient client = new ScriptedRouteClient();
    private final PlatformLedgerFake platformLedger = new PlatformLedgerFake();
    private final StaticEvidence evidence = new StaticEvidence();
    private final ToolPortStub toolPort = new ToolPortStub();
    private final AlertClockStub clock = new AlertClockStub();
    private final UUID runId = UUID.randomUUID();
    private final UUID attemptId = UUID.randomUUID();

    /** 注册表含第四个同运行器角色（纯配置；RX01 证明主体）+ BA-112 schema 钉版面角色 */
    private final AgentRegistry agents = new AgentRegistry(List.of(
            primaryProfile(), expertProfile("metrics-expert"), expertProfile("logs-expert"),
            fourthRoleProfile(), schemaProfile()));

    private DeterministicSupervisor supervisor;
    private BoundedLlmRoleRunner boundedRunner;
    private RunnerDirectory directory;
    private SingleToolRoleRunner singleToolRunner;
    private RcaActionGuard guardRef;
    private ContextAssembler assemblerRef;

    @BeforeEach
    void setUp() {
        stores.runs.insert(new RcaRun(runId, UUID.randomUUID(), 0, RunTrigger.RERUN,
                RcaRunState.QUEUED, Digest.sha256Of("material"), NOW, NOW, null,
                null, null));
        supervisor = new DeterministicSupervisor(
                new PlanCompiler(agents, stores.tasks, edges, stores.bindings, inPlaceTx()),
                new DagExecutionService(edges, stores.tasks),
                stores.runs, stores.tasks, stores.bindings, stores.checkpoints,
                stores.delegationDecisions, agents, inPlaceTx(), clock);

        ExecutionLedger rcaSinkLedger = new ExecutionLedger(
                new com.objwww.pr.control.infrastructure.persistence.RcaModelEventSink(
                        stores.rcaEvents, new ObjectMapper()));
        ModelGateway platform = new ModelGateway(ROUTE, null, client, null,
                params(), platformLedger, new PricingService(Map.of()), rcaSinkLedger, CLOCK);
        RcaModelGateway rcaGateway = new RcaModelGateway(platform, stores.modelCalls,
                new PricingService(Map.of()),
                new com.objwww.pr.control.alert.support.AlertInMemoryStores.InputCaptures(
                        com.objwww.pr.control.alert.domain.agent.RcaModelInputCapture.Level.DIGEST_ONLY),
                CLOCK);
        RunBudgetGate gate = new RunBudgetGate(new InMemoryRunBudgetLedger());
        gate.openRun(runId, Map.of(BudgetKind.TOKEN, 1_000_000L));
        RcaActionGuard guard = new RcaActionGuard(stores.runs, stores.tasks, agents,
                gate, rcaGateway, CLOCK);
        this.guardRef = guard;

        ContextAssembler assembler = new ContextAssembler(evidence, stores.toolLedger,
                stores.delegationDecisions,
                run -> ContextAssembler.AlertMaterial.unknown(), MAPPER);
        this.assemblerRef = assembler;
        boundedRunner = new BoundedLlmRoleRunner(guard, supervisor, stores.checkpoints,
                evidence, assembler, toolPort, MAPPER, CLOCK, commitFence());
        singleToolRunner = new SingleToolRoleRunner(Map.of("metrics-expert",
                (ctx, start, end) -> null));
        directory = new RunnerDirectory(List.of(boundedRunner, singleToolRunner));
    }

    // ------------------------------------------------- RX01 第四角色纯配置可执行

    @Test
    void rx01第四个同运行器角色_纯配置即被目录解析并执行() {
        AgentProfile fourth = fourthRoleProfile();
        // ① 注册表获准（同一份配置：requireExact 精确三元组）
        assertThat(agents.requireExact(fourth.name(), fourth.version(), fourth.digest()))
                .isEqualTo(fourth);
        // ② 目录按 runtime_kind 解析到同一个 BoundedLlmRoleRunner 实例（零新 Java 分派）
        assertThat(directory.requireFor(fourth)).isSameAs(boundedRunner);

        // ③ 绑定第四角色的主任务可执行：脚本 TOOL_CALL → 受控口取证 → 计步
        UUID taskId = seedBoundPrimaryTask(fourth);
        seedCheckpoint(taskId, 0);
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"code.read\",\"args\":{\"path\":\"a.java\"}}}",
                new TokenUsage(20, 10, 30), false, "model-rca", "req-1",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(request(taskId, fourth));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.EVIDENCE_PRODUCED);
        assertThat(toolPort.invocations).hasSize(1);
        assertThat(toolPort.invocations.get(0).toolId()).isEqualTo("code.read");
        assertThat(stores.checkpoints.findByTask(taskId).orElseThrow().stepsUsed())
                .isEqualTo(1);
        assertThat(client.calls()).isEqualTo(1);
    }

    // ------------------------------------------------- RX03 未知运行器/角色拒绝

    @Test
    void rx03未部署运行器类型_目录显式拒绝_零触网() {
        AgentProfile ghost = new AgentProfile("ghost", "1", "prompt-ghost", "pv",
                Set.of(), Map.of(), Map.of("type", "object"), Map.of(),
                AgentPhase.INVESTIGATE, "not-deployed-kind", Set.of(), 1, "single-pass");

        assertThatThrownBy(() -> directory.requireFor(ghost))
                .isInstanceOf(RunnerDirectory.CapabilityUnavailableException.class)
                .hasMessageContaining("CAPABILITY_UNAVAILABLE");
        assertThat(client.calls()).as("准入期拒绝零触网").isZero();
        assertThat(directory.deployedKinds()).containsExactlyInAnyOrder(
                RoleRuntimeKind.BOUNDED_LLM, RoleRuntimeKind.DETERMINISTIC_SINGLE_TOOL);
    }

    @Test
    void 绑定角色无兼容适配_单工具运行器显式拒绝() {
        SingleToolRoleRunner narrow = new SingleToolRoleRunner(Map.of("metrics-expert",
                (ctx, start, end) -> null));
        AgentProfile known = expertProfile("logs-expert");
        TaskExecutionBinding binding = new TaskExecutionBinding(UUID.randomUUID(), runId,
                0, "investigate-logs", "ghost-role", "1",
                Digest.sha256Of("ghost").hex(), null, null, List.of(), Map.of(), null,
                true, TaskExecutionBinding.FailurePolicy.DEAD_ON_FAILURE, NOW);
        RoleRunner.RoleDriveRequest request = new RoleRunner.RoleDriveRequest(
                leasedTask(UUID.randomUUID()), binding, known, callCtx(), "1", "2");

        assertThatThrownBy(() -> narrow.drive(request))
                .isInstanceOf(RunnerDirectory.CapabilityUnavailableException.class)
                .hasMessageContaining("ghost-role");
    }

    // ------------------------------------------------- BoundedLlm 单步语义

    @Test
    void waitingChildren子任务未收官_零模型调用等待() {
        UUID primaryId = startPrimary();
        supervisor.adjudicateDelegation(runId, primaryId, PrimaryDecision.parse(
                Map.of("delegate", Map.of("requests", List.of(
                        request("gap-1", "metrics-expert"))))));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.WAITING_CHILDREN);
        assertThat(client.calls()).as("等待面零模型调用").isZero();
    }

    @Test
    void wake后继续_TOOL_CALL取证_计步与账面SUCCESS() {
        UUID primaryId = startPrimary();
        supervisor.adjudicateDelegation(runId, primaryId, PrimaryDecision.parse(
                Map.of("delegate", Map.of("requests", List.of(
                        request("gap-1", "metrics-expert"))))));
        finishChildren(1);
        supervisor.wakePrimary(runId, primaryId);
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"q\":\"err\"}}}",
                new TokenUsage(20, 10, 30), false, "model-rca", "req-2",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.EVIDENCE_PRODUCED);
        assertThat(toolPort.invocations).hasSize(1);
        PrimaryCheckpoint checkpoint = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(checkpoint.stepsUsed()).isEqualTo(1);
        assertThat(stores.modelCalls.all().get(0).state()).isEqualTo("SUCCESS");
    }

    @Test
    void toolCall越权_allowlist外工具_计步拒绝不触口() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"code.search\",\"args\":{}}}",
                new TokenUsage(20, 10, 30), false, "model-rca", "req-3",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.FAILED);
        assertThat(result.reason()).isEqualTo("TOOL_NOT_ALLOWED");
        assertThat(toolPort.invocations).as("越权工具不触受控口").isEmpty();
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().stepsUsed())
                .isEqualTo(1);
    }

    @Test
    void final提案_代码准入降级与越界剥离落检查点() {
        UUID primaryId = startPrimary();
        UUID evidenceId = evidence.seed();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"final\":{\"claims\":["
                        + "{\"claim_key\":\"c1\",\"kind\":\"ROOT_CAUSE\",\"statement\":\"无引用断言\",\"evidence_refs\":[]},"
                        + "{\"claim_key\":\"c2\",\"kind\":\"ROOT_CAUSE\",\"statement\":\"有本run引用\",\"evidence_refs\":[\""
                        + evidenceId + "\",\"6c3c6c3c-0000-0000-0000-000000000000\"]}],"
                        + "\"missing_information\":[\"部署时间线\"]}}",
                new TokenUsage(20, 10, 30), false, "model-rca", "req-4",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.FINAL_READY);
        PrimaryCheckpoint checkpoint = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(checkpoint.finalClaims()).hasSize(2);
        assertThat(checkpoint.finalClaims().get(0))
                .as("零有效引用 ROOT_CAUSE 降级 HYPOTHESIS（RD05）")
                .containsEntry("kind", "HYPOTHESIS")
                .containsEntry("admission_note",
                        PrimaryClaimAdmission.NOTE_DOWNGRADED_NO_EVIDENCE);
        assertThat((List<Object>) checkpoint.finalClaims().get(1).get("evidence_refs"))
                .as("越界引用剥离，只留本 run 证据")
                .containsExactly(evidenceId.toString());
        assertThat(checkpoint.finalMissingInformation()).containsExactly("部署时间线");
    }

    @Test
    void steps耗尽_确定性兜底FINAL_零模型调用() {
        UUID primaryId = startPrimary();
        // steps 已耗尽（maxSteps=1，已用 1）：重驱不花模型调用直接兜底
        stores.checkpoints.upsert(
                stores.checkpoints.findByTask(primaryId).orElseThrow().withStepAdvanced(
                        null, null, null, null, NOW));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.FINAL_READY);
        assertThat(result.reason()).isEqualTo("STEPS_EXHAUSTED");
        assertThat(client.calls()).as("§四 终止兜底零模型调用").isZero();
        PrimaryCheckpoint checkpoint = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(checkpoint.finalClaims()).isEmpty();
        assertThat(checkpoint.finalMissingInformation().get(0)).contains("STEPS_EXHAUSTED");
    }

    @Test
    void decision不可解析_计步重驱不静默重放() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok("这不是JSON决策",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-5",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.FAILED);
        assertThat(result.reason()).isEqualTo("DECISION_UNPARSEABLE");
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().stepsUsed())
                .isEqualTo(1);
    }

    // ------------------------------------------------- BA-110 真模型协议面

    @Test
    void ba110围栏包装决策_整形后正常解析取证() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "```json\n{\"tool_call\":{\"tool_id\":\"logs.query\","
                        + "\"args\":{\"query\":\"error\"}}}\n```",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-b1",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).as("markdown 围栏整形后按 TOOL_CALL 驱动")
                .isEqualTo(RoleRunner.RoleDriveOutcome.EVIDENCE_PRODUCED);
        assertThat(toolPort.invocations).hasSize(1);
        assertThat(toolPort.invocations.get(0).toolId()).isEqualTo("logs.query");
    }

    @Test
    void ba110提示词携带runner拥有的输出协议后缀() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"final\":{\"claims\":[],\"missing_information\":[\"x\"]}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-b2",
                Duration.ofMillis(5)));

        boundedRunner.drive(request(primaryId, primaryProfile()));

        assertThat(client.prompts).hasSize(1);
        assertThat(client.prompts.get(0))
                .as("协议后缀随信封逐步下发，不依赖可配置 prompt 记得携带")
                .contains("【输出协议（硬性）】")
                .contains("\"tool_call\"")
                .contains("\"final\"")
                .contains("valid_artifact_refs");
    }

    // ------------------------------------------------- BA-112 参数形状面

    @Test
    void ba112工具参数形状拒绝_计步重驱而非DEAD() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"bad\":1}}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-b3",
                Duration.ofMillis(5)));
        toolPort.failWith = new com.objwww.pr.control.alert.domain.tool
                .ToolControlPlaneException(com.objwww.pr.control.alert.domain.tool
                        .ToolControlReason.INVALID_ARGS, "INVALID_ARGS: 形状不符");

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).as("INVALID_ARGS 对模型驱动环=计步重驱")
                .isEqualTo(RoleRunner.RoleDriveOutcome.FAILED);
        assertThat(result.reason()).isEqualTo("TOOL_RETRYABLE:INVALID_ARGS");
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().stepsUsed())
                .isEqualTo(1);
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().lastError())
                .as("V88 反馈环：INVALID_ARGS 修正指引+执行器具体拒因落检查点，下步信封回喂"
                        + "（BA-183：模型能从拒因学会修参，不是只见 INVALID_INPUT 码）")
                .isNotNull().contains("INVALID_ARGS").contains("tool_schemas")
                .contains("形状不符");
        toolPort.failWith = null;
    }

    @Test
    void ba112工具schema钉版随信封下发() {
        AgentProfile withSchemas = schemaProfile();
        UUID taskId = seedBoundPrimaryTask(withSchemas);
        seedCheckpoint(taskId, 0);
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"final\":{\"claims\":[],\"missing_information\":[\"x\"]}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-b4",
                Duration.ofMillis(5)));

        boundedRunner.drive(request(taskId, withSchemas));

        assertThat(client.prompts.get(0))
                .as("tool_schemas 钉版随信封下发（BA-112 模型取参依据）")
                .contains("tool_schemas").contains("\"since\"");
    }

    @Test
    void ba181工具用途描述随信封下发_schema形状逐字节不变() {
        AgentProfile withSchemas = schemaProfile();
        UUID taskId = seedBoundPrimaryTask(withSchemas);
        seedCheckpoint(taskId, 0);
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"final\":{\"claims\":[],\"missing_information\":[\"x\"]}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-b5",
                Duration.ofMillis(5)));

        boundedRunner.drive(request(taskId, withSchemas));

        assertThat(client.prompts.get(0))
                .as("BA-181：逐工具中文用途描述入信封（模型选工具不再只有裸 schema）")
                .contains("\"description\":\"查冻结窗内的服务日志")
                .contains("\"properties\":{\"since\":{\"type\":\"string\"}}");
    }

    // ------------------------------------------------- BA-181 熔断签名单步化

    @Test
    void ba181熔断签名命中_计步重驱而非DEAD() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"service\":\"order-arena\"}}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-d1",
                Duration.ofMillis(5)));
        toolPort.failWith = new com.objwww.pr.control.alert.domain.tool
                .ToolControlPlaneException(com.objwww.pr.control.alert.domain.tool
                        .ToolControlReason.DOOM_LOOP_TRIPPED,
                        "DOOM_LOOP_TRIPPED: 重复同参调用熔断触发");

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome()).as("BA-181：熔断的是签名不是调查——计步重驱而非整任务 DEAD")
                .isEqualTo(RoleRunner.RoleDriveOutcome.FAILED);
        assertThat(result.reason()).isEqualTo("TOOL_RETRYABLE:DOOM_LOOP_TRIPPED");
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().stepsUsed())
                .isEqualTo(1);
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().lastError())
                .as("V88 反馈环：熔断禁令与出路落检查点，下步信封 last_error 面下发")
                .isNotNull().contains("DOOM_LOOP_TRIPPED").contains("禁止同参重发")
                .contains("change.query");
        toolPort.failWith = null;
    }

    @Test
    void ba181真终止族预算耗尽_维持上抛DEAD() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"service\":\"order-arena\"}}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-d2",
                Duration.ofMillis(5)));
        toolPort.failWith = new com.objwww.pr.control.alert.domain.tool
                .ToolControlPlaneException(com.objwww.pr.control.alert.domain.tool
                        .ToolControlReason.BUDGET_EXHAUSTED,
                        "BUDGET_EXHAUSTED: 本 Run 工具调用预算耗尽");

        assertThatThrownBy(() -> boundedRunner.drive(request(primaryId, primaryProfile())))
                .as("BA-181：BUDGET_EXHAUSTED 真终止族行为不变（上抛由执行器降级 DEAD）")
                .isInstanceOf(com.objwww.pr.control.alert.domain.tool
                        .ToolControlPlaneException.class);
        toolPort.failWith = null;
    }

    // ------------------------------------------------- BA-119 委派全拒反馈环

    @Test
    void ba119委派全拒_拒绝码与修正指引写lastError回喂() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"delegate\":{\"requests\":[{\"gap_id\":\"g-x\","
                        + "\"role_id\":\"nonexistent-role\",\"question\":\"q\","
                        + "\"input_refs\":[],\"scope\":{},\"requested_budget\":4}]}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-d1",
                Duration.ofMillis(5)));

        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile()));

        assertThat(result.outcome())
                .isEqualTo(RoleRunner.RoleDriveOutcome.DELEGATE_REJECTED);
        assertThat(result.reason()).contains("ROLE_UNKNOWN");
        var checkpoint = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(checkpoint.stepsUsed()).as("全拒不耗步（X4 状态不动）").isEqualTo(0);
        assertThat(checkpoint.decisionSeq()).as("决策序仍单调推进").isEqualTo(1);
        assertThat(checkpoint.lastError())
                .as("BA-119：全拒原因+修正指引落检查点，下步信封 last_error 面回喂"
                        + "（修复前盲重提同一 gap 烧尽驱动上限）")
                .contains("DELEGATE_REJECTED").contains("ROLE_UNKNOWN")
                .contains("final");
    }

    // ------------------------------------------------- R5 同签名模型失败熔断（BA-120/MC25）

    @Test
    void 同签名模型失败两次_第二次确定性未决收敛_不再重发() {
        UUID primaryId = startPrimary();
        // 两脚本行 = 同参同败两次（PROTOCOL_ERROR 终态族，retryable=false）
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.ProtocolError(FaultScope.ENDPOINT),
                null, null, null, Duration.ofMillis(3)));
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.ProtocolError(FaultScope.ENDPOINT),
                null, null, null, Duration.ofMillis(3)));

        // 第 1 次：原样上抛（现有重驱语义不动），检查点留失败签名、零计数推进
        assertThatThrownBy(() -> boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID())))
                .isInstanceOf(RcaModelCallException.class)
                .hasFieldOrPropertyWithValue("errorCode", "PROTOCOL_ERROR");
        var afterFirst = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(afterFirst.lastError()).startsWith("MODEL_FAILURE_SIGNATURE:");
        assertThat(afterFirst.stepsUsed()).as("失败步不耗步数").isZero();

        // 第 2 次（重驱=新 attempt）：同签名 → 确定性未决 FINAL（零第三次模型调用）
        RoleRunner.RoleDriveResult result = boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID()));

        assertThat(result.outcome()).isEqualTo(RoleRunner.RoleDriveOutcome.FINAL_READY);
        assertThat(result.reason()).isEqualTo("MODEL_FAILURE_PROTOCOL_ERROR");
        var checkpoint = stores.checkpoints.findByTask(primaryId).orElseThrow();
        assertThat(checkpoint.finalClaims()).isEmpty();
        assertThat(checkpoint.finalMissingInformation())
                .singleElement().asString().contains("MODEL_FAILURE_UNRESOLVED")
                .contains("PROTOCOL_ERROR");
        assertThat(client.calls()).as("恰两次模型调用，无风暴").isEqualTo(2);
    }

    @Test
    void 不同失败码_不判同签名_熔断不误触发() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.ProtocolError(FaultScope.ENDPOINT),
                null, null, null, Duration.ofMillis(3)));
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.RequestInvalid(FaultScope.MODEL),
                400, null, null, Duration.ofMillis(3)));

        assertThatThrownBy(() -> boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID())))
                .hasFieldOrPropertyWithValue("errorCode", "PROTOCOL_ERROR");
        assertThatThrownBy(() -> boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID())))
                .as("码不同 = 非同签名，第 2 次仍上抛不收敛")
                .hasFieldOrPropertyWithValue("errorCode", "REQUEST_INVALID");
        assertThat(client.calls()).isEqualTo(2);
    }

    @Test
    void 步级可重试失败_DEFERRED_不进熔断() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.QuotaTemporary(FaultScope.ACCOUNT, NOW.plusSeconds(60)),
                429, null, null, Duration.ofMillis(3)));
        client.enqueue(new RouteCallOutcome.Failed(
                new ModelCallFailure.QuotaTemporary(FaultScope.ACCOUNT, NOW.plusSeconds(60)),
                429, null, null, Duration.ofMillis(3)));

        // DEFERRED（retryable=true）两次同样上抛——配额冷却属正常运营，不判终态
        assertThatThrownBy(() -> boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID())))
                .hasFieldOrPropertyWithValue("errorCode", "DEFERRED");
        assertThatThrownBy(() -> boundedRunner.drive(
                request(primaryId, primaryProfile(), UUID.randomUUID())))
                .hasFieldOrPropertyWithValue("errorCode", "DEFERRED");
        assertThat(stores.checkpoints.findByTask(primaryId).orElseThrow().lastError())
                .as("可重试失败不留熔断签名").isNull();
    }

    // ------------------------------------- 单步输出预算旋钮（deepseek 推理模型适配）

    @Test
    void stepMaxTokens默认1000_既有构造器链恒缺省() {
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"query\":\"error\"}}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-t1",
                Duration.ofMillis(5)));
        boundedRunner.drive(request(primaryId, primaryProfile()));
        assertThat(client.maxTokensSeen).containsExactly(1000);
    }

    @Test
    void stepMaxTokens配置放大2000_直达模型请求() {
        // 推理模型 reasoning_tokens 计入输出预算（195 实证 deepseek
        // OUTPUT_BUDGET_EXHAUSTED）——11 参构造器注入 2000，值直达网关
        BoundedLlmRoleRunner widened = new BoundedLlmRoleRunner(guardRef, supervisor,
                stores.checkpoints, evidence, assemblerRef, toolPort, MAPPER, CLOCK,
                null, commitFence(), 2000);
        UUID primaryId = startPrimary();
        client.enqueue(new RouteCallOutcome.Ok(
                "{\"tool_call\":{\"tool_id\":\"logs.query\",\"args\":{\"query\":\"error\"}}}",
                new TokenUsage(5, 0, 5), false, "model-rca", "req-t2",
                Duration.ofMillis(5)));
        widened.drive(request(primaryId, primaryProfile()));
        assertThat(client.maxTokensSeen).containsExactly(2000);
    }

    @Test
    void stepMaxTokens非正_构造即拒() {
        assertThatThrownBy(() -> new BoundedLlmRoleRunner(guardRef, supervisor,
                stores.checkpoints, evidence, assemblerRef, toolPort, MAPPER, CLOCK,
                null, commitFence(), 0))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("stepMaxTokens");
    }

    // ------------------------------------------------- 夹具

    /** 主模式启动（PlanCompiler 编译事务写绑定+检查点），返回主任务 id */
    private UUID startPrimary() {
        supervisor.startPrimary(runId, primaryProfile(), Set.of());
        return stores.tasks.findByRunId(runId).stream()
                .filter(t -> t.taskKey().equals(RcaTask.PRIMARY_INVESTIGATE))
                .findFirst().orElseThrow().id();
    }

    /** RX01 面：绕过 startPrimary 手工播种第四角色的任务+绑定+检查点（绑定即配置） */
    private UUID seedBoundPrimaryTask(AgentProfile profile) {
        UUID taskId = UUID.randomUUID();
        stores.tasks.insert(new RcaTask(taskId, runId, RcaTask.PRIMARY_INVESTIGATE,
                RcaTaskState.READY, 5, NOW, NOW, Instant.MAX, null, null, 0, 0, 2,
                NOW, NOW, 0));
        stores.bindings.insert(new TaskExecutionBinding(taskId, runId, 0,
                RcaTask.PRIMARY_INVESTIGATE, profile.name(), profile.version(),
                profile.digest(), null, null, List.of(), profile.outputSchema(), null,
                true, TaskExecutionBinding.FailurePolicy.DEAD_ON_FAILURE, NOW));
        return taskId;
    }

    private void seedCheckpoint(UUID taskId, int round) {
        stores.checkpoints.upsert(PrimaryCheckpoint.initial(taskId, runId, round, NOW));
    }

    private RoleRunner.RoleDriveRequest request(UUID taskId, AgentProfile profile) {
        return request(taskId, profile, attemptId);
    }

    /** attempt 显式注入面（R5 熔断面：重驱=新 attempt，预算键随之新开不撞旧结算） */
    private RoleRunner.RoleDriveRequest request(UUID taskId, AgentProfile profile, UUID attempt) {
        RcaTask task = stores.tasks.findById(taskId).orElseThrow();
        TaskExecutionBinding binding = stores.bindings.findByTask(taskId).orElseThrow();
        return new RoleRunner.RoleDriveRequest(task, binding, profile, callCtx(attempt),
                "1757574000", "1757577600");
    }

    private SingleToolEvidenceAgent.CallContext callCtx() {
        return callCtx(attemptId);
    }

    private SingleToolEvidenceAgent.CallContext callCtx(UUID attempt) {
        return new SingleToolEvidenceAgent.CallContext(runId, UUID.randomUUID(),
                attempt, 0, 0, null, "1757574000/1757577600");
    }

    private RcaTask leasedTask(UUID taskId) {
        return new RcaTask(taskId, runId, RcaTask.PRIMARY_INVESTIGATE, RcaTaskState.READY,
                5, NOW, NOW, Instant.MAX, null, null, 0, 0, 2, NOW, NOW, 0);
    }

    private void finishChildren(int round) {
        for (RcaTask child : stores.tasks.findByRunId(runId)) {
            if (!child.taskKey().equals(RcaTask.PRIMARY_INVESTIGATE)
                    && child.roundId() == round) {
                stores.tasks.transitionState(child.id(), child.state(), RcaTaskState.DONE);
            }
        }
    }

    private static Map<String, Object> request(String gapId, String roleId) {
        Map<String, Object> req = new LinkedHashMap<>();
        req.put("gap_id", gapId);
        req.put("role_id", roleId);
        req.put("question", "q-" + gapId);
        req.put("input_refs", List.of());
        req.put("scope", Map.of());
        req.put("requested_budget", 4);
        return req;
    }

    private static AgentProfile primaryProfile() {
        // maxSteps=1：steps 耗尽兜底面单测可触发（§四建议 8 为待评测上限，非契约值）
        return new AgentProfile("primary", "1", "prompt-primary", "pv",
                Set.of("logs.query", "code.read"), Map.of(BudgetKind.STEP, 8L),
                Map.of("type", "object"), Map.of(), AgentPhase.PRIMARY,
                RoleRuntimeKind.BOUNDED_LLM, Set.of(), 1, "single-pass");
    }

    private static AgentProfile expertProfile(String name) {
        return new AgentProfile(name, "1", "prompt-" + name, "pv",
                Set.of(), Map.of(BudgetKind.STEP, 4L), Map.of("type", "object"),
                Map.of(), AgentPhase.INVESTIGATE,
                RoleRuntimeKind.DETERMINISTIC_SINGLE_TOOL, Set.of(), 1, "single-pass");
    }

    /** 第四个同运行器角色（RX01）：只新增配置（Profile），无任何新 Java 分派 */
    private static AgentProfile fourthRoleProfile() {
        return new AgentProfile("code-searcher", "1", "prompt-code", "pv",
                Set.of("code.read"), Map.of(BudgetKind.STEP, 4L),
                Map.of("type", "object"), Map.of(), AgentPhase.PRIMARY,
                RoleRuntimeKind.BOUNDED_LLM, Set.of(), 4, "single-pass");
    }

    /** BA-112 schema 钉版面：inputSchema 携带工具 args JSON Schema（进 digest 钉版） */
    private static AgentProfile schemaProfile() {
        return new AgentProfile("schema-primary", "1", "prompt-schema", "pv",
                Set.of("logs.query"), Map.of(BudgetKind.STEP, 4L),
                Map.of("type", "object"),
                Map.of("logs.query", Map.of("type", "object",
                        "properties", Map.of("since", Map.of("type", "string")))),
                AgentPhase.PRIMARY, RoleRuntimeKind.BOUNDED_LLM, Set.of(), 4, "single-pass");
    }

    private static ModelGatewayParams params() {
        // maxCompletionTokensPerCall 对齐生产默认 16_000（application.yml），
        // 否则 step-max-tokens 放大面被测试夹具自身的天花板误拒
        return new ModelGatewayParams(
                0, 4, 1_000, 16_000, 100_000,
                Duration.ofSeconds(30), Duration.ofMillis(1), Duration.ofSeconds(5),
                4, Duration.ofSeconds(10), Duration.ofMillis(1), Duration.ofMillis(5),
                "test-provider", "v1");
    }

    private static TransactionOperations inPlaceTx() {
        return new TransactionOperations() {
            @Override
            public <T> T execute(TransactionCallback<T> action) {
                return action.doInTransaction(null);
            }
        };
    }

    /** CL-01 提交围栏（假件面：in-place 事务 + 无代际史 epoch 源 + 记忆随提交 append） */
    private PrimaryCheckpointCommitService commitFence() {
        return new PrimaryCheckpointCommitService(stores.runs, stores.tasks,
                stores.checkpoints,
                com.objwww.pr.control.alert.domain.repository.RunConfigEpochRepository.NO_OP,
                clock, inPlaceTx(), stores.workingMemories);
    }

    private static final class AlertClockStub implements com.objwww.pr.control.alert.application.AlertClock {
        @Override
        public Instant now() {
            return NOW;
        }
    }

    /** 最小边仓储内存件 */
    private static final class EdgeStore implements TaskEdgeRepository {
        final List<TaskEdge> rows = new ArrayList<>();

        @Override
        public void insert(UUID runId, UUID fromTaskId, UUID toTaskId,
                DependencyType dependencyType) {
            rows.add(new TaskEdge(fromTaskId.toString(), toTaskId.toString(),
                    dependencyType));
        }

        @Override
        public List<TaskEdge> findByRunId(UUID runId) {
            return rows.stream().toList();
        }
    }

    /** 固定单行证据仓（FINAL 准入 validRefs 面） */
    private static final class StaticEvidence implements EvidenceRepository {
        private final List<EvidenceEnvelope> rows = new ArrayList<>();

        UUID seed() {
            UUID id = UUID.randomUUID();
            rows.add(new EvidenceEnvelope(id, UUID.randomUUID(), UUID.randomUUID(),
                    "logs.query", EvidenceEnvelope.SCHEMA_VERSION, 0, "loki",
                    Map.of("time_range", "1/2"), NOW, NOW, "{}",
                    Digest.sha256Of("{}").hex()));
            return id;
        }

        @Override
        public void insert(EvidenceEnvelope envelope) {
            rows.add(envelope);
        }

        @Override
        public Optional<EvidenceEnvelope> findById(UUID evidenceId) {
            return rows.stream().filter(e -> e.evidenceId().equals(evidenceId))
                    .findFirst();
        }

        @Override
        public List<EvidenceEnvelope> findByRunId(UUID runId) {
            return rows.stream().toList();
        }
    }

    /** 受控口存根：记录越权面与取证调用；failWith 在场时抛出（INVALID_ARGS 面） */
    private static final class ToolPortStub implements BoundedLlmRoleRunner.PrimaryToolPort {
        record Invocation(UUID taskId, String toolId, Map<String, Object> args) {
        }

        final List<Invocation> invocations = new ArrayList<>();
        RuntimeException failWith;

        @Override
        public UUID invoke(SingleToolEvidenceAgent.CallContext ctx, String toolId,
                Map<String, Object> args) {
            invocations.add(new Invocation(ctx.taskId(), toolId, args));
            if (failWith != null) {
                throw failWith;
            }
            return UUID.randomUUID();
        }
    }

    /** 脚本化路由客户端（零真网） */
    private static final class ScriptedRouteClient implements RouteClientPort {
        private final Queue<RouteCallOutcome> script = new ArrayDeque<>();
        private final List<String> prompts = new ArrayList<>();
        private final List<Integer> maxTokensSeen = new ArrayList<>();
        private int calls;

        void enqueue(RouteCallOutcome outcome) {
            script.add(outcome);
        }

        int calls() {
            return calls;
        }

        @Override
        public RouteCallOutcome complete(ModelRequest request, Duration timeout) {
            calls++;
            prompts.add(request.prompt());
            maxTokensSeen.add(request.maxTokens());
            return script.poll();
        }
    }

    /** 平台账本假件 */
    private static final class PlatformLedgerFake implements ModelCallLedgerRepository {
        final List<ModelCallLedgerEntry> rows = new ArrayList<>();

        @Override
        public void insertStarted(ModelCallLedgerEntry entry) {
            rows.add(entry);
        }

        @Override
        public boolean completeTerminalSuccess(UUID id, TokenUsage usage,
                boolean usageMissing, String reportedModel, String providerRequestId,
                Duration latency, Long costMicros, String pricingVersion, String currency,
                Long inputPriceMicrosPerK, Long outputPriceMicrosPerK) {
            return true;
        }

        @Override
        public boolean completeTerminalFailure(UUID id, String outcome, Integer httpStatus,
                Duration retryAfter, Duration latency, String errorCode,
                String errorFingerprint, String sanitizedMessage) {
            return true;
        }

        @Override
        public int markUnknownOlderThan(Instant threshold) {
            return 0;
        }
    }
}
