package com.objwww.pr.control.it;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.objwww.pr.shared.Digest;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * control-app 集成测试基座（与 publisher 侧 PostgresITBase 同形态，M1-T02 引入）：
 * Testcontainers 真 PG（postgres:16-alpine）+ 真实角色/授权/Flyway 迁移（V1~V6 在本模块
 * classpath:db/migration）。
 *
 * <p>形态：
 * <ul>
 *   <li>静态容器全 IT 类共享一个 PG 实例；每个测试方法前 TRUNCATE 全部业务表清场
 *       （V1~V32 全表，见 ALL_TABLES，RESTART IDENTITY CASCADE 兜底）；</li>
 *   <li>admin（容器超级用户）先执行与 deploy/db/01-roles.sh 等价的 DO 块创建
 *       control_app / publisher_app 两角色（V2/V3 的 grant 依赖两角色存在），
 *       再以 admin 身份跑 Flyway；</li>
 *   <li>之后测试只经三条 DataSource 触库：admin（清场/拨时间等测试动作）、
 *       control_app、publisher_app——应用路径的角色权限由真实授权兜底；</li>
 *   <li>INC-09：3.10 内核宿主必须 seccomp=unconfined，否则 initdb EPERM；</li>
 *   <li>本机无 docker 时整类自动跳过（disabledWithoutDocker），本机 mvn test 不受影响。</li>
 * </ul>
 */
@Testcontainers(disabledWithoutDocker = true)
public abstract class PostgresITBase {

    protected static final String CONTROL_ROLE = "control_app";
    protected static final String PUBLISHER_ROLE = "publisher_app";
    protected static final String NOTIFY_ROLE = "notify_app";
    protected static final String EVAL_ROLE = "eval_app";
    protected static final String CONTROL_PASSWORD = "it-control-pass";
    protected static final String PUBLISHER_PASSWORD = "it-publisher-pass";
    protected static final String NOTIFY_PASSWORD = "it-notify-pass";
    protected static final String EVAL_PASSWORD = "it-eval-pass";

    /** V1~V32 全业务表清单（BA-41，195 真 PG 实证）：原清单冻结在 AM2 时代，V20~V29
     *  的 AM5 表不在列——跨类污染在 195 类序（GoldenCandidate 先于 DatasetVersion）
     *  下以 FK 违约爆出。TRUNCATE 单语句 + CASCADE 顺序无关；config_bundle /
     *  config_bundle_active 除外（V24 种子行 id=1 是激活 CAS 的依赖面，
     *  ConfigBundleRepositoryTest 自管两表，见各 setUp）。 */
    private static final List<String> ALL_TABLES = List.of(
            "pr_subject", "pr_revision", "review_run", "run_step", "work_item", "step_attempt",
            "execution_event", "outbox_command", "outbox_dependency", "publication_resource",
            "review_finding", "artifact", "webhook_inbox", "step_checkpoint", "repair_request",
            "model_call_ledger", "tool_call", "sandbox_job", "artifact_grant",
            "alert_inbox", "alert_event", "incident", "rca_run", "rca_task", "rca_attempt",
            "rca_report", "external_invocation_ledger", "scheduler_slot", "rca_task_edge",
            "rca_investigation_result", "rca_tool_call", "report_publication", "notify_outbox",
            "eval_case_result", "eval_run",
            // V80（EV-03 阶段事件）+ V81（EV-04 生命周期命令）——BA-41 同律
            "eval_phase_event", "eval_run_command",
            // V20~V29（AM5）：rca_event 为 V28 分区父表，TRUNCATE 级联全部分区
            "dataset_version", "case_version", "case_family_partition",
            "golden_candidate", "golden_review_event",
            "canary_route_decision", "operator_case", "operator_command",
            "rca_event",
            "retention_policy", "legal_hold", "archive_manifest",
            // V16~V17（AM4 证据/Claim 面）+ V30（AM6 canary 两表）——BA-41 同律：
            // 业务表必须入清单，缺表 = 跨类污染在类序变化下以脏数据爆出
            "rca_evidence", "rca_evidence_snapshot", "rca_snapshot_member",
            "rca_claim", "canary_evidence_sample", "canary_window_verdict",
            // V32（AM6 M6-02 引擎对照结论）——BA-41 同律
            "engine_comparison",
            // V33（AM6 M6-04 run 级 fallback 栅栏 + 发布赢家）——BA-41 同律
            "run_fallback", "report_generation_winner",
            // V34（AM6 M6-05 Holmes shadow 持久工作面）——BA-41 同律
            "holmes_shadow_work",
            // V13（AM4 预算账本）——BA-41 同律：此前零消费者故缺表不显形，
            // EX-A1BudgetAdmissionIT 起成为真 PG 消费者（EX-A1 首钉）
            "run_budget_state", "run_budget_entry",
            // V40（EX-B1 变更事实）——BA-41 同律（config_bundle 两表仍由组件测试自管）
            "change_event",
            // V60（EN-01 发布资产）+ V61（EN-02 发布资格）——BA-41 同律：
            // 两表无种子行，入清单统一清场（qualification 的 FK 由单语句 CASCADE 消化）
            "release_asset", "release_qualification",
            // V63（EN-04 配置代际史）——BA-41 同律：En04ConfigEpochIT 起成为真 PG 消费者
            "rca_run_config_epoch",
            // V64（EN-06 MCP server 注册表）——BA-41 同律：En06McpRegistryIT 起成为真 PG 消费者
            "mcp_server_registry",
            // V43（AM7 值班八表）——BA-41 同律：PostgresDutyStoreIT 起成为真 PG 消费者
            "duty_delivery", "duty_notification", "duty_layer_member", "duty_layer",
            "duty_override", "duty_channel", "duty_member", "duty_schedule",
            // V82（UX-01 分类 override 审计）——BA-41 同律
            "incident_category_override",
            // V83（UX-02 仿真机器人两表）——BA-41 同律
            "chat_message", "chat_session",
            // V85（EV-07 对比结论落档）——BA-41 同律
            "eval_comparison",
            // V86（DR-02 演练作业链两表）——BA-41 同律（事件表引用作业表，序敏感）
            "drill_event", "drill_job",
            // V95（DR-05 flagd 恢复台账）——BA-41 同律：
            // PostgresFlagdRestoreLedgerIT 起成为真 PG 消费者
            "flagd_restore_ledger",
            // V87（EV-08 评审两表）——BA-41 同律（结论表引用任务表，序敏感）
            "review_verdict", "review_assignment",
            // V90（R2 输入捕获档）——BA-41 同律：PostgresRcaModelInputIT 起成为真 PG 消费者
            "rca_model_input",
            // V91（R10 工作记忆快照）——BA-41 同律：PostgresWorkingMemoryIT 起成为真 PG 消费者
            "rca_working_memory",
            // V92（R11 上下文压缩摘要）——BA-41 同律：PostgresContextSummaryIT 起成为真 PG 消费者
            "rca_context_summary",
            // V96（MC21~23 回执台账 + MC31/32 人工材料）——BA-41 同律：
            // PostgresDelegationReceiptIT / PostgresOperatorMaterialIT 起成为真 PG 消费者
            "rca_delegation_receipt", "incident_operator_material",
            // V97（EN-08 Skill 候选生命周期）——BA-41 同律：
            // PostgresSkillCandidateIT 起成为真 PG 消费者
            "rca_skill_candidate",
            // V100（CL-05 Skill 运行绑定）——BA-41 同律：
            // PostgresRunSkillBindingIT 起成为真 PG 消费者
            "rca_run_skill_binding",
            // V102（CL-07 压缩尝试台账）——BA-41 同律：
            // PostgresCompactionAttemptIT 起成为真 PG 消费者
            "rca_compaction_attempt",
            // V103/V104/V105（OP 批：报告反馈/回归候选/动作分析）——BA-41 同律：
            // PostgresOpBatchIT 起成为真 PG 消费者
            "report_feedback", "rca_regression_candidate", "rca_regression_review",
            "rca_action_assessment");

    @SuppressWarnings("resource") // 容器由 ryuk 回收；静态生命周期贯穿整个 IT JVM
    protected static final PostgreSQLContainer<?> PG =
            new PostgreSQLContainer<>("postgres:16-alpine")
                    // INC-09：老内核宿主的 seccomp 不支持新镜像 syscall 面
                    .withCreateContainerCmdModifier(cmd -> cmd.getHostConfig()
                            .withSecurityOpts(List.of("seccomp=unconfined")));

    private static HikariDataSource adminDs;
    private static HikariDataSource controlDs;
    private static HikariDataSource publisherDs;
    private static HikariDataSource notifyDs;
    private static HikariDataSource evalDs;

    protected static JdbcClient adminJdbc;
    protected static JdbcClient controlJdbc;
    protected static JdbcClient publisherJdbc;
    protected static JdbcClient notifyJdbc;
    protected static JdbcClient evalJdbc;
    protected static TransactionTemplate controlTx;
    protected static TransactionTemplate publisherTx;
    /** EX-B1：admin 侧事务（SET ROLE deploy_app + INSERT 同连接面——池化下两条 sql() 可能异连） */
    protected static TransactionTemplate adminTx;

    private static synchronized void ensureStarted() {
        if (adminDs != null) {
            return;
        }
        PG.start();

        adminDs = pool(PG.getUsername(), PG.getPassword(), 2);
        adminJdbc = JdbcClient.create(adminDs);

        // 与 deploy/db/01-roles.sh 等价的幂等角色创建（授权在 V2/V3/V9，以 owner 身份跑 Flyway）
        adminJdbc.sql("""
                do $$
                begin
                    if not exists (select from pg_roles where rolname = 'control_app') then
                        create role control_app login password '%s';
                    else
                        alter role control_app with login password '%s';
                    end if;
                    if not exists (select from pg_roles where rolname = 'publisher_app') then
                        create role publisher_app login password '%s';
                    else
                        alter role publisher_app with login password '%s';
                    end if;
                    if not exists (select from pg_roles where rolname = 'notify_app') then
                        create role notify_app login password '%s';
                    else
                        alter role notify_app with login password '%s';
                    end if;
                    if not exists (select from pg_roles where rolname = 'eval_app') then
                        create role eval_app login password '%s';
                    else
                        alter role eval_app with login password '%s';
                    end if;
                end
                $$;
                """.formatted(CONTROL_PASSWORD, CONTROL_PASSWORD,
                PUBLISHER_PASSWORD, PUBLISHER_PASSWORD,
                NOTIFY_PASSWORD, NOTIFY_PASSWORD,
                EVAL_PASSWORD, EVAL_PASSWORD))
                .update();

        Flyway.configure()
                .dataSource(adminDs)
                .locations("classpath:db/migration")
                // V9 的 notify_app 角色密码走 placeholder（部署面由 migrate 服务注入，同语义）
                .placeholders(Map.of("notify_password", NOTIFY_PASSWORD))
                .load()
                .migrate();

        controlDs = pool(CONTROL_ROLE, CONTROL_PASSWORD, 24);
        publisherDs = pool(PUBLISHER_ROLE, PUBLISHER_PASSWORD, 6);
        notifyDs = pool(NOTIFY_ROLE, NOTIFY_PASSWORD, 6);
        evalDs = pool(EVAL_ROLE, EVAL_PASSWORD, 6);
        controlJdbc = JdbcClient.create(controlDs);
        publisherJdbc = JdbcClient.create(publisherDs);
        notifyJdbc = JdbcClient.create(notifyDs);
        evalJdbc = JdbcClient.create(evalDs);
        controlTx = new TransactionTemplate(new DataSourceTransactionManager(controlDs));
        publisherTx = new TransactionTemplate(new DataSourceTransactionManager(publisherDs));
        adminTx = new TransactionTemplate(new DataSourceTransactionManager(adminDs));
    }

    private static HikariDataSource pool(String user, String password, int size) {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(PG.getJdbcUrl());
        config.setUsername(user);
        config.setPassword(password);
        config.setMaximumPoolSize(size);
        return new HikariDataSource(config);
    }

    static {
        ensureStarted();
    }

    @BeforeEach
    void truncateAll() {
        adminJdbc.sql("TRUNCATE " + String.join(", ", ALL_TABLES) + " RESTART IDENTITY CASCADE")
                .update();
    }

    // 连接池与静态容器同生命周期（贯穿整个 failsafe fork），不随单个测试类关闭。

    // ------------------------------------------------------------------ 测试动作助手

    protected static DataSource controlDataSource() {
        return controlDs;
    }

    protected static DataSource publisherDataSource() {
        return publisherDs;
    }

    /** admin 计数（断言 DB 全貌用，绕开角色视角） */
    protected long count(String table) {
        return adminJdbc.sql("SELECT count(*) FROM " + table).query(Long.class).single();
    }

    /** EN-02 资格门 fixture：为目标 digest 直插一条未撤销 PASS 证明（admin 面，
     *  绕过服务门——仓储级激活种子专用；门语义见 V61 头注） */
    protected static void grantPassQualification(Digest candidate) {
        adminJdbc.sql("""
                INSERT INTO release_qualification (
                    id, candidate_digest, dataset_manifest_digest,
                    runner_version, grader_version, quality_verdict, usage_status,
                    granted_scope, granted_by, granted_at)
                VALUES (:id, :c, :ds, 'runner-it', 'grader-it', 'PASS', 'UNKNOWN',
                        'it-scope', 'it', now())
                """)
                .param("id", UUID.randomUUID())
                .param("c", candidate.hex())
                .param("ds", "e".repeat(64))
                .update();
    }

    // ------------------------------------------------------------------ M2 修复链路种子助手（CT-22/25/27/28/29 共用）

    /** 修复链路测试骨架：subject + current revision + 已完结 NORMAL run（漂移检测发生时的典型现场）。 */
    protected record RepairSeed(UUID subjectId, UUID revisionId, UUID runId) {}

    private static final AtomicLong SEED_SEQ = new AtomicLong(10_000);

    /**
     * 造一 PR 骨架（admin）：subject（next_outbox_sequence=2，给原命令留 sequence=1）
     * + revision（设为 current）+ COMPLETED 的 NORMAL run。列清单 V3/V4 通用（CT-22 在 V3 形态库复用）。
     */
    protected static RepairSeed seedRepairScope(String tag) {
        return seedRepairScope(adminJdbc, tag);
    }

    /** 同 {@link #seedRepairScope(String)}，写入指定库（CT-22 的独立升级库用）。 */
    protected static RepairSeed seedRepairScope(JdbcClient jdbc, String tag) {
        long n = SEED_SEQ.getAndIncrement();
        RepairSeed seed = new RepairSeed(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());
        String d = Digest.sha256Of("seed-" + tag + "-" + n).value();
        jdbc.sql("""
                INSERT INTO pr_subject(id,github_installation_id,github_repository_id,repository_full_name,
                    pr_number,state,draft,merged,current_policy_version,publication_epoch,
                    next_outbox_sequence,last_resolved_sequence,version,created_at,updated_at)
                VALUES (:s,1,:repo,'octo/demo',:pr,'OPEN',false,false,'p',1,2,0,0,now(),now())
                """).param("s", seed.subjectId()).param("repo", n).param("pr", (int) (n % Integer.MAX_VALUE))
                .update();
        jdbc.sql("""
                INSERT INTO pr_revision(id,pr_subject_id,head_sha,base_ref,base_sha,diff_digest,
                    revision_fingerprint,observed_at,created_at)
                VALUES (:r,:s,:head,'main','base',:d,:d,now(),now())
                """).param("r", seed.revisionId()).param("s", seed.subjectId())
                .param("head", "head-" + tag + "-" + n).param("d", d).update();
        jdbc.sql("UPDATE pr_subject SET current_revision_id=:r WHERE id=:s")
                .param("r", seed.revisionId()).param("s", seed.subjectId()).update();
        jdbc.sql("""
                INSERT INTO review_run(id,pr_revision_id,run_key,trigger_key,run_mode,policy_version,
                    prompt_version,toolset_version,state,publisher_disabled,version,created_at,updated_at,
                    completed_at)
                VALUES (:id,:r,:key,'ct','NORMAL','p','prompt','tools','COMPLETED',false,0,now(),now(),now())
                """).param("id", seed.runId()).param("r", seed.revisionId())
                .param("key", Digest.sha256Of("run-" + tag + "-" + n).value()).update();
        return seed;
    }

    /**
     * 在骨架上插一条 CONFIRMED 原命令（aggregate_sequence=1，与 subject.next_outbox_sequence=2 配套，
     * 后续 repair 命令经 SequenceAllocator 取 2，天然单调）；payload_hash 取 payload 正文的 sha256，
     * 与 RepairPlanner 按 digest 读 CAS 的约定一致。返回 operation_id。
     */
    protected static UUID seedConfirmedCommand(RepairSeed seed, String commandType, String payloadJson) {
        return seedConfirmedCommand(adminJdbc, seed, commandType, payloadJson);
    }

    /** 同 {@link #seedConfirmedCommand(RepairSeed, String, String)}，写入指定库。 */
    protected static UUID seedConfirmedCommand(JdbcClient jdbc, RepairSeed seed,
                                               String commandType, String payloadJson) {
        UUID operationId = UUID.randomUUID();
        String hash = Digest.sha256Of(payloadJson).value();
        String remoteIdentityType = switch (commandType) {
            case "CREATE_CHECK" -> "EXTERNAL_ID";
            case "UPDATE_CHECK" -> "CHECK_RUN_ID";
            default -> "REVIEW_MARKER";
        };
        jdbc.sql("""
                INSERT INTO outbox_command(operation_id,pr_subject_id,review_run_id,pr_revision_id,
                    aggregate_key,aggregate_sequence,publication_epoch,fence_mode,command_type,state,
                    policy_version,payload_artifact_digest,payload_hash,remote_identity_type,
                    attempt_count,max_attempts,created_at,updated_at,confirmed_at)
                VALUES (:op,:s,:run,:rev,:agg,1,1,'CURRENT_EPOCH',:type,'CONFIRMED',
                    'p',:hash,:hash,:rit,1,3,now(),now(),now())
                """).param("op", operationId).param("s", seed.subjectId()).param("run", seed.runId())
                .param("rev", seed.revisionId()).param("agg", "agg-" + seed.subjectId())
                .param("type", commandType).param("hash", hash)
                .param("rit", remoteIdentityType).update();
        return operationId;
    }

    /** 插一条由指定命令创建的资源行（uq(resource_type, remote_id)，remoteId 须唯一），返回资源 id。 */
    protected static UUID seedResource(RepairSeed seed, UUID commandOperationId,
                                       String resourceType, String state, String remoteId) {
        return seedResource(adminJdbc, seed, commandOperationId, resourceType, state, remoteId);
    }

    /** 同 {@link #seedResource(RepairSeed, UUID, String, String, String)}，写入指定库。 */
    protected static UUID seedResource(JdbcClient jdbc, RepairSeed seed, UUID commandOperationId,
                                       String resourceType, String state, String remoteId) {
        UUID resourceId = UUID.randomUUID();
        jdbc.sql("""
                INSERT INTO publication_resource(id,resource_type,created_by_operation_id,pr_subject_id,
                    remote_id,remote_url,state,created_at,updated_at)
                VALUES (:id,:type,:op,:s,:rid,:url,:state,now(),now())
                """).param("id", resourceId).param("type", resourceType).param("op", commandOperationId)
                .param("s", seed.subjectId()).param("rid", remoteId)
                .param("url", "https://api.github.test/" + remoteId).param("state", state).update();
        return resourceId;
    }

    /**
     * 铸一条 repair_request（admin）。V4 trg_repair_insert_pending 强制 INSERT 只能以 PENDING
     * 出生且审批三列恒空，因此目标态经随后 UPDATE 抵达（APPROVED 自动补审计三列，
     * RETRY_WAIT 把 next_attempt_at 拨到过去立即可领）。返回 request id。
     */
    protected static UUID seedRepairRequest(UUID resourceId, String resourceType, String tier,
                                            String targetState, int attemptCount, int maxAttempts,
                                            long createdAgeSeconds) {
        UUID id = UUID.randomUUID();
        adminJdbc.sql("""
                INSERT INTO repair_request(id,publication_resource_id,resource_type,policy_tier,state,
                    attempt_count,max_attempts,created_at,updated_at)
                VALUES (:id,:rid,:rtype,:tier,'PENDING',0,:maxA,
                    now()-make_interval(secs => :age),now()-make_interval(secs => :age))
                """).param("id", id).param("rid", resourceId).param("rtype", resourceType)
                .param("tier", tier).param("maxA", maxAttempts).param("age", createdAgeSeconds).update();
        if (!"PENDING".equals(targetState)) {
            adminJdbc.sql("""
                    UPDATE repair_request SET state=:state, attempt_count=:ac,
                        approved_by = CASE WHEN :state='APPROVED' THEN 'seed-approver' END,
                        approved_at = CASE WHEN :state='APPROVED' THEN now() END,
                        approval_reason = CASE WHEN :state='APPROVED' THEN 'seed approval' END,
                        next_attempt_at = CASE WHEN :state='RETRY_WAIT' THEN now()-interval '1 second' END,
                        updated_at=now()
                     WHERE id=:id
                    """).param("state", targetState).param("ac", attemptCount).param("id", id).update();
        }
        return id;
    }

    /** 读 repair_request 当前 state（admin 视角）。 */
    protected static String repairStateOf(UUID requestId) {
        return adminJdbc.sql("SELECT state FROM repair_request WHERE id=:id")
                .param("id", requestId).query(String.class).single();
    }
}
